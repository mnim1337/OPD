"""Контроль валидатора на эталоне и его намеренно повреждённых копиях.
Запуск: python test_validation.py <папка_с_четырьмя_эталонными_файлами>
"""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import sys
import tempfile
import unittest
from fractions import Fraction
import validate_export as v

REFERENCE=Path(sys.argv.pop(1)).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent/'pak_export_reference_v1'

class ExportTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)/'data'
        shutil.copytree(REFERENCE,self.root)
    def tearDown(self):self.tmp.cleanup()
    def manifest(self):return json.loads((self.root/'experiment.json').read_text(encoding='utf-8'))
    def save_manifest(self,m):
        (self.root/'experiment.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    def rows(self,name):
        with (self.root/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
    def save_rows(self,name,rows,header=None):
        with (self.root/name).open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=header or v.HEADERS[name],lineterminator='\r\n')
            w.writeheader();w.writerows(rows)
        m=self.manifest();raw=(self.root/name).read_bytes()
        m['export_status']['tables'][name]={'row_count':len(rows),'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        self.save_manifest(m)
    def bad(self):
        with self.assertRaises((v.ValidationError,ValueError,KeyError,TypeError)):v.validate(self.root)
    def test_01_original_passes(self):
        s,w,c=v.validate(self.root);self.assertEqual(w,[]);self.assertEqual(s['row_counts']['packets.csv'],40)
    def test_02_independent_reference_numbers(self):
        s,w,c=v.validate(self.root);m=v.control_metrics(c)
        self.assertAlmostEqual(m['mean_delay_s'],float((28*Fraction('0.0332896')+10*Fraction('0.0382896'))/38),14)
        self.assertAlmostEqual(m['balance_index'],float(Fraction(8308,13125)),14)
        self.assertEqual(m['goodput_bps'],36000*8/10)
        self.assertEqual(m['routing_bytes_evaluation_window'],12000-600+2500+3000)
        self.assertEqual(m['channel_data_bytes_full_capture'],38*4*1028)
        self.assertEqual(m['stability_ratio'],6/8);self.assertEqual(m['restricted_mean_reroute_time_s'],0.5)
    def test_03_missing_file(self):
        (self.root/'routes.csv').unlink();self.bad()
    def test_04_fifth_file(self):
        (self.root/'extra.txt').write_text('x');self.bad()
    def test_05_wrong_version(self):
        m=self.manifest();m['schema_version']='0.9';self.save_manifest(m);self.bad()
    def test_06_header_renamed(self):
        p=self.root/'packets.csv';p.write_bytes(p.read_bytes().replace(b'tx_time_s',b'tx_time_ms',1));self.bad()
    def test_07_wrong_delimiter(self):
        p=self.root/'packets.csv';p.write_bytes(p.read_bytes().replace(b',',b';'));self.bad()
    def test_08_bom(self):
        p=self.root/'packets.csv';p.write_bytes(b'\xef\xbb\xbf'+p.read_bytes());self.bad()
    def test_09_hash_mismatch(self):
        m=self.manifest();m['export_status']['tables']['packets.csv']['sha256']='0'*64;self.save_manifest(m);self.bad()
    def test_10_duplicate_packet(self):
        r=self.rows('packets.csv');r[1]['packet_id']=r[0]['packet_id'];self.save_rows('packets.csv',r);self.bad()
    def test_11_receive_before_send(self):
        r=self.rows('packets.csv');r[0]['rx_time_s']='0.100000000';self.save_rows('packets.csv',r);self.bad()
    def test_12_receive_without_copy(self):
        r=self.rows('packets.csv');r[0]['rx_copy_count']='0';self.save_rows('packets.csv',r);self.bad()
    def test_13_negative_payload(self):
        r=self.rows('packets.csv');r[0]['payload_bytes']='-1';self.save_rows('packets.csv',r);self.bad()
    def test_14_unknown_flow(self):
        r=self.rows('packets.csv');r[0]['flow_id']='UNDECLARED';self.save_rows('packets.csv',r);self.bad()
    def test_15_other_experiment(self):
        r=self.rows('packets.csv');r[0]['experiment_id']='OTHER';self.save_rows('packets.csv',r);self.bad()
    def test_16_unknown_channel(self):
        r=self.rows('channels.csv');r[0]['link_id']='UNKNOWN';self.save_rows('channels.csv',r);self.bad()
    def test_17_broken_path(self):
        r=self.rows('routes.csv');r[0]['path_links']='["L_S01_S02","L_S04_G02"]';self.save_rows('routes.csv',r);self.bad()
    def test_18_route_gap(self):
        r=self.rows('routes.csv');r[0]['time_end_s']='5.210000000';self.save_rows('routes.csv',r);self.bad()
    def test_19_no_route_with_path(self):
        r=self.rows('routes.csv');x=next(x for x in r if x['route_state']=='no_route');x['path_links']='["L_G01_S01"]';self.save_rows('routes.csv',r);self.bad()
    def test_20_reused_path_id_different_path(self):
        r=self.rows('routes.csv');x=next(x for x in r if x['flow_id']=='F01' and x['route_set_id']=='F01_RS04')
        x['path_links']='["L_G01_S01","L_S01_S03","L_S03_S04","L_S04_G02"]'
        self.save_rows('routes.csv',r);self.bad()
    def test_21_transmission_on_down_link(self):
        r=self.rows('channels.csv');x=next(x for x in r if x['link_up']=='0');x['tx_data_bytes']='100';self.save_rows('channels.csv',r);self.bad()
    def test_22_negative_counter(self):
        r=self.rows('channels.csv');r[0]['tx_data_bytes']='-1';self.save_rows('channels.csv',r);self.bad()
    def test_23_counter_missing_but_complete(self):
        r=self.rows('channels.csv');r[0]['tx_routing_bytes']='';self.save_rows('channels.csv',r);self.bad()
    def test_24_channel_gap(self):
        r=self.rows('channels.csv');r[0]['time_end_s']='0.900000000';self.save_rows('channels.csv',r);self.bad()
    def test_25_using_planned_time_instead_of_actual(self):
        m=self.manifest();m['scenario']['events'][0]['actual_time_s']=5.0;self.save_manifest(m);self.bad()
    def test_26_over_capacity(self):
        r=self.rows('channels.csv');r[0]['tx_data_bytes']='1000000000';self.save_rows('channels.csv',r);self.bad()
    def test_27_unknown_observation_is_not_zero_loss(self):
        r=self.rows('packets.csv');r[0]['observation_status']='unknown';self.save_rows('packets.csv',r)
        s,w,c=v.validate(self.root);self.assertTrue(w);self.assertFalse(v.control_metrics(c)['available'])
    def test_28_stale_installed_route_is_not_format_error(self):
        s,w,c=v.validate(self.root)
        self.assertTrue(any(r['_a']<v.D('5.02')<r['_b'] and 'L_S02_S04' in r['_path'] for r in c['by_flow']['F01']))
        self.assertEqual(v.control_metrics(c)['stability_ratio'],0.75)
    def test_29_changed_real_experiment_id_is_allowed(self):
        m=self.manifest();m['experiment_id']='EXP_OTHER_001';self.save_manifest(m)
        for name in v.HEADERS:
            r=self.rows(name)
            for x in r:x['experiment_id']='EXP_OTHER_001'
            self.save_rows(name,r)
        s,w,c=v.validate(self.root);self.assertEqual(s['experiment_id'],'EXP_OTHER_001')
    def test_30_clock_uncertainty_does_not_get_exact_control_numbers(self):
        m=self.manifest();m['measurement']['clock_error_bound_s']=0.001;self.save_manifest(m)
        s,w,c=v.validate(self.root);self.assertFalse(v.control_metrics(c)['available'])
    def test_31_export_not_finished(self):
        m=self.manifest();m['export_status']['complete']=False;self.save_manifest(m);self.bad()
    def test_32_duplicate_json_key(self):
        p=self.root/'experiment.json';s=p.read_text();s=s.replace('"schema_version": "1.0.0",','"schema_version": "1.0.0", "schema_version": "1.0.0",',1);p.write_text(s);self.bad()

if __name__=='__main__':unittest.main(verbosity=2)

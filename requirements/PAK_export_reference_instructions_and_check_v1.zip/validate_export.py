#!/usr/bin/env python3
"""Проверка четырехфайловой выгрузки PAK_ROUTING_EXPORT_4F, версия 1.0.0.
Стандартная библиотека Python. Проверяет данные, а не эффективность ПАК.
Не исполняет загруженный алгоритм и не является полным оценочным приложением.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import re
import sys
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

HEADERS = {
    'packets.csv': ['experiment_id','flow_id','packet_id','tx_time_s','rx_time_s','payload_bytes','rx_copy_count','observed_until_s','observation_status','drop_reason'],
    'routes.csv': ['experiment_id','flow_id','route_set_id','path_id','time_start_s','time_end_s','path_links','route_state','selection_share','cause_event_id'],
    'channels.csv': ['experiment_id','link_id','time_start_s','time_end_s','link_up','capacity_bps','propagation_delay_s','routing_cost','tx_data_bytes','tx_routing_bytes','tx_other_bytes','observation_status','queue_mean_bytes','queue_max_bytes','drop_data_packets'],
}
EXPECTED_FILES = {'experiment.json', *HEADERS}
ID_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')
STATES = {'complete','partial','unknown'}
ROUTE_STATES = {'installed','no_route','loop','unknown'}
D = Decimal
EPS = D('0.000000001')

class ValidationError(ValueError):
    pass

def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)

def pairs_no_duplicates(pairs: list) -> dict:
    d = {}
    for k, v in pairs:
        need(k not in d, f'Повторяющийся ключ JSON: {k}')
        d[k] = v
    return d

def reject_constant(value: str) -> None:
    raise ValidationError(f'Недопустимое значение JSON: {value}')

def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'),
                      object_pairs_hook=pairs_no_duplicates,
                      parse_constant=reject_constant)

def number(value: Any, label: str, minimum: Decimal | None = None) -> Decimal:
    need(value is not None and value != '' and not isinstance(value, bool), f'{label}: требуется число')
    try:
        result = D(str(value))
    except InvalidOperation as exc:
        raise ValidationError(f'{label}: неверное число {value!r}') from exc
    need(result.is_finite(), f'{label}: число должно быть конечным')
    if minimum is not None:
        need(result >= minimum, f'{label}: число меньше допустимого минимума {minimum}')
    return result

def integer(value: Any, label: str, minimum: int = 0) -> int:
    need(not isinstance(value, bool) and bool(re.fullmatch(r'0|[1-9][0-9]*', str(value))), f'{label}: требуется целое неотрицательное число')
    result = int(value)
    need(result >= minimum, f'{label}: минимальное значение {minimum}')
    return result

def identifier(value: Any, label: str) -> str:
    need(isinstance(value, str) and ID_RE.fullmatch(value) is not None, f'{label}: неверный идентификатор')
    return value

def required(obj: dict, keys: list[str], label: str) -> None:
    need(isinstance(obj, dict), f'{label}: требуется объект JSON')
    missing = set(keys) - set(obj)
    need(not missing, f'{label}: отсутствуют поля {sorted(missing)}')

def read_csv(path: Path, header: list[str]) -> list[dict]:
    raw = path.read_bytes()
    need(not raw.startswith(b'\xef\xbb\xbf'), f'{path.name}: BOM не разрешён данной версией формата')
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError as exc:
        raise ValidationError(f'{path.name}: требуется UTF-8') from exc
    need('\x00' not in text, f'{path.name}: обнаружен нулевой байт')
    need(raw.endswith(b'\r\n'), f'{path.name}: строки должны оканчиваться CRLF')
    rest = raw.replace(b'\r\n', b'')
    need(b'\n' not in rest and b'\r' not in rest, f'{path.name}: неверное окончание строк или перенос внутри ячейки')
    with path.open('r',encoding='utf-8',newline='') as f:
        rd = csv.DictReader(f, delimiter=',', quotechar='"', strict=True)
        need(rd.fieldnames == header, f'{path.name}: заголовки или их порядок не соответствуют спецификации')
        rows = []
        for line, row in enumerate(rd, 2):
            need(None not in row and all(v is not None for v in row.values()), f'{path.name}:{line}: неверное число полей')
            row['_line'] = line
            rows.append(row)
    return rows

def cover(rows: list[dict], start: Decimal, end: Decimal, label: str) -> None:
    need(bool(rows), f'{label}: отсутствуют интервалы')
    sorted_rows = sorted(rows, key=lambda r: r['_a'])
    pos = start
    for r in sorted_rows:
        need(r['_a'] == pos, f'{label}: разрыв или перекрытие интервалов около {pos}')
        need(r['_b'] > r['_a'], f'{label}: пустой или обратный интервал')
        pos = r['_b']
    need(pos == end, f'{label}: история должна завершаться в {end}, а не {pos}')

def validate(folder: Path) -> tuple[dict, list[str], dict]:
    warnings = []
    need(folder.is_dir(), 'Указанный путь не является папкой')
    names = {p.name for p in folder.iterdir() if p.is_file()}
    need(names == EXPECTED_FILES, f'В папке должны быть ровно 4 файла. Недостают: {sorted(EXPECTED_FILES-names)}; лишние: {sorted(names-EXPECTED_FILES)}')
    need(not (folder/'experiment.json').read_bytes().startswith(b'\xef\xbb\xbf'), 'experiment.json: BOM не разрешён')
    m = read_json(folder/'experiment.json')
    required(m,['format_name','schema_version','data_origin','description_ru','experiment_id','scenario_id','repeat_id','algorithm','environment','network','traffic','scenario','measurement','file_contract','export_status','extensions'],'experiment.json')
    need(m['format_name']=='PAK_ROUTING_EXPORT_4F' and m['schema_version']=='1.0.0','Не поддерживаются имя или версия формата')
    need(m['data_origin'] in {'synthetic_reference','pak_export','external_simulator_export','manual_prepared'},'Неверное data_origin')
    exp=identifier(m['experiment_id'],'experiment_id');identifier(m['scenario_id'],'scenario_id')
    integer(m['repeat_id'],'repeat_id',1)
    required(m['algorithm'],['algorithm_id','implementation_version','routing_mode','settings','settings_completeness'],'algorithm')
    identifier(m['algorithm']['algorithm_id'],'algorithm_id')
    need(isinstance(m['algorithm']['settings'],dict),'algorithm.settings: требуется объект')
    need(m['algorithm']['routing_mode'] in {'single_path_per_flow','multipath_per_flow'},'Неподдерживаемый routing_mode')
    required(m['environment'],['execution_source','pak_version','time_mode','hardware_description','queue_discipline','buffer_limit_bytes','link_errors','randomness'],'environment')
    required(m['environment']['randomness'],['used','seeds'],'environment.randomness')
    need(isinstance(m['environment']['randomness']['used'],bool) and isinstance(m['environment']['randomness']['seeds'],dict),'Неверное описание генераторов случайных чисел')
    if m['data_origin']=='pak_export':
        need(bool(m['environment']['pak_version']),'Для pak_export требуется фактическая версия ПАК')
    meas=m['measurement']
    required(meas,['capture_start_s','capture_end_s','evaluation_start_s','evaluation_end_s','loss_timeout_s','time_base','timestamp_resolution_s','clock_error_bound_s','interval_convention','packet_tx_point','packet_rx_point','route_observation_mode','route_time_error_bound_s','channel_nominal_interval_s','channel_grid_rule','channel_counter_mode','channel_counter_point','channel_byte_scope','channel_categories_disjoint','channel_max_atomic_packet_bytes','balance','stability','adaptivity'],'measurement')
    cs=number(meas['capture_start_s'],'capture_start_s',D(0));ce=number(meas['capture_end_s'],'capture_end_s',D(0))
    es=number(meas['evaluation_start_s'],'evaluation_start_s',D(0));ee=number(meas['evaluation_end_s'],'evaluation_end_s',D(0))
    timeout=number(meas['loss_timeout_s'],'loss_timeout_s',D(0))
    need(cs<=es<ee<=ce and timeout>0,'Несогласованы временные окна')
    need(number(meas['timestamp_resolution_s'],'timestamp_resolution_s')>0,'Точность времени должна быть положительной')
    number(meas['clock_error_bound_s'],'clock_error_bound_s',D(0));number(meas['route_time_error_bound_s'],'route_time_error_bound_s',D(0))
    need(meas['interval_convention']=='[start,end)','Неверное соглашение о границах интервалов')
    need(meas['channel_counter_mode']=='interval_delta','Ожидались приращения счётчиков по интервалам')
    need(meas['channel_categories_disjoint'] is True,'Категории переданных байтов должны быть непересекающимися')
    atom=integer(meas['channel_max_atomic_packet_bytes'],'channel_max_atomic_packet_bytes',1)
    fc=m['file_contract']
    for key,value in [('encoding','UTF-8'),('bom',False),('csv_delimiter',','),('decimal_separator','.'),('csv_quotechar','"'),('csv_line_ending','CRLF'),('csv_null','empty_field')]:
        need(fc.get(key)==value,f'file_contract.{key}: ожидалось {value!r}')
    need(fc.get('table_headers')==HEADERS,'Объявленные заголовки отличаются от схемы 1.0.0')
    required(m['network'],['network_id','directed','nodes','links'],'network')
    need(m['network']['directed'] is True,'Соединения должны быть направленными')
    nodes={}
    for n in m['network']['nodes']:
        required(n,['node_id','node_type','plane_id','initial_up'],'node')
        nid=identifier(n['node_id'],'node_id');need(nid not in nodes,'Повтор node_id')
        need(isinstance(n['initial_up'],bool),'initial_up: требуется JSON boolean');nodes[nid]=n
    links={}
    for e in m['network']['links']:
        required(e,['link_id','node_from','node_to','interface_from','interface_to','link_type','initial_up','initial_capacity_bps','initial_propagation_delay_s','initial_routing_cost','resource_allocation'],'link')
        lid=identifier(e['link_id'],'link_id');need(lid not in links,'Повтор link_id')
        need(e['node_from'] in nodes and e['node_to'] in nodes and e['node_from']!=e['node_to'],f'{lid}: неверные концы канала')
        need(isinstance(e['initial_up'],bool),f'{lid}: initial_up должен быть boolean')
        number(e['initial_capacity_bps'],f'{lid}: capacity',D(0));number(e['initial_propagation_delay_s'],f'{lid}: delay',D(0))
        number(e['initial_routing_cost'],f'{lid}: routing_cost')
        links[lid]=e
    flows={}
    for f in m['traffic']['flows']:
        required(f,['flow_id','source_node','destination_node','transport','packetization','generation'],'flow')
        fid=identifier(f['flow_id'],'flow_id');need(fid not in flows,'Повтор flow_id')
        need(f['source_node'] in nodes and f['destination_node'] in nodes,f'{fid}: неизвестные узлы потока')
        flows[fid]=f
    need(bool(nodes) and bool(links) and bool(flows),'Нужны непустые списки узлов, каналов и потоков')
    events={}
    for e in m['scenario']['events']:
        required(e,['event_id','event_type','object_type','object_ids','scheduled_time_s','actual_time_s','result','changes'],'event')
        eid=identifier(e['event_id'],'event_id');need(eid not in events,'Повтор event_id')
        number(e['scheduled_time_s'],f'{eid}: planned',cs)
        if e['result']=='executed':
            t=number(e['actual_time_s'],f'{eid}: actual',cs);need(t<ce,'Событие вне интервала регистрации')
        if e['object_type']=='directed_links':
            need(set(e['object_ids']).issubset(links),f'{eid}: неизвестный канал')
        elif e['object_type']=='nodes':
            need(set(e['object_ids']).issubset(nodes),f'{eid}: неизвестный узел')
        elif e['object_type']=='flows':
            need(set(e['object_ids']).issubset(flows),f'{eid}: неизвестный поток')
        else:raise ValidationError(f'{eid}: неизвестный тип объекта')
        events[eid]=e
    tables={name:read_csv(folder/name,head) for name,head in HEADERS.items()}
    required(m['export_status'],['complete','data_logging_complete','lost_log_records','logging_gaps','tables'],'export_status')
    need(m['export_status']['complete'] is True,'Экспорт ещё не завершён')
    need(isinstance(m['export_status']['data_logging_complete'],bool),'data_logging_complete: требуется boolean')
    integer(m['export_status']['lost_log_records'],'lost_log_records')
    if not m['export_status']['data_logging_complete'] or m['export_status']['lost_log_records'] or m['export_status']['logging_gaps']:
        warnings.append('В паспорте указана неполнота регистрации; точные контрольные показатели могут быть недоступны.')
    for name,rows in tables.items():
        stat=m['export_status']['tables'].get(name,{})
        required(stat,['row_count','size_bytes','sha256'],f'export_status.tables.{name}')
        raw=(folder/name).read_bytes()
        need(integer(stat['row_count'],f'{name}: row_count')==len(rows),f'{name}: число строк не совпадает с паспортом')
        need(integer(stat['size_bytes'],f'{name}: size')==len(raw),f'{name}: размер не совпадает с паспортом')
        need(stat['sha256']==hashlib.sha256(raw).hexdigest(),f'{name}: SHA-256 не совпадает с паспортом')
        for r in rows:need(r['experiment_id']==exp,f'{name}:{r["_line"]}: чужой experiment_id')
    packets=tables['packets.csv'];seen=set()
    for r in packets:
        label=f'packets.csv:{r["_line"]}'
        identifier(r['packet_id'],label+' packet_id')
        need(r['packet_id'] not in seen,label+': повтор packet_id');seen.add(r['packet_id'])
        need(r['flow_id'] in flows,label+': неизвестный flow_id')
        r['_tx']=number(r['tx_time_s'],label+' tx');r['_obs']=number(r['observed_until_s'],label+' observed')
        need(cs<=r['_tx']<ce and r['_tx']<=r['_obs']<=ce,label+': несогласованное время наблюдения')
        r['_size']=integer(r['payload_bytes'],label+' payload',1);r['_copies']=integer(r['rx_copy_count'],label+' copies')
        need(r['observation_status'] in STATES,label+': неверный observation_status')
        if r['rx_time_s']:
            r['_rx']=number(r['rx_time_s'],label+' rx')
            need(r['_tx']<=r['_rx']<=r['_obs'] and r['_rx']<ce,label+': приём раньше отправки или за пределами наблюдения')
            need(r['_copies']>=1,label+': при зарегистрированном приёме copies должно быть >=1')
            need(r['drop_reason']=='',label+': у полученного пакета не должно быть причины окончательной потери')
        else:
            r['_rx']=None;need(r['_copies']==0,label+': без rx_time_s copies должно быть 0')
        if r['observation_status']!='complete':warnings.append(label+': неполное наблюдение пакета')
        if r['_rx'] is None and r['_obs']<r['_tx']+timeout:warnings.append(label+': ожидание доставки не завершено')
    channels=tables['channels.csv'];by_link=defaultdict(list)
    for r in channels:
        label=f'channels.csv:{r["_line"]}';lid=r['link_id']
        need(lid in links,label+': неизвестный link_id')
        r['_a']=number(r['time_start_s'],label+' start');r['_b']=number(r['time_end_s'],label+' end')
        need(cs<=r['_a']<r['_b']<=ce,label+': неверный интервал')
        need(r['link_up'] in {'0','1'},label+': link_up должен быть 0 или 1')
        r['_up']=r['link_up']=='1';r['_cap']=number(r['capacity_bps'],label+' capacity',D(0))
        number(r['propagation_delay_s'],label+' delay',D(0))
        if r['routing_cost']:number(r['routing_cost'],label+' cost')
        need(r['observation_status'] in STATES,label+': неверный observation_status')
        for key in ['tx_data_bytes','tx_routing_bytes','tx_other_bytes']:
            if r[key]=='':
                need(r['observation_status']!='complete',label+': при complete обязательны счётчики');r['_'+key]=None
            else:r['_'+key]=integer(r[key],label+' '+key)
        for key in ['queue_mean_bytes','queue_max_bytes']:
            if r[key]:number(r[key],label+' '+key,D(0))
        if r['drop_data_packets']:integer(r['drop_data_packets'],label+' drop_data_packets')
        if r['queue_mean_bytes'] and r['queue_max_bytes']:
            need(D(r['queue_mean_bytes'])<=D(r['queue_max_bytes']),label+': средняя очередь больше максимальной')
        total=sum(r['_'+k] or 0 for k in ['tx_data_bytes','tx_routing_bytes','tx_other_bytes'])
        if not r['_up']:need(r['_cap']==0 and total==0,label+': у отключённого канала ненулевая ёмкость или передача')
        else:need(r['_cap']>0,label+': доступный канал должен иметь положительную ёмкость')
        need(D(8*total)<=r['_cap']*(r['_b']-r['_a'])+8*atom,label+': счётчики превышают ресурс интервала и допуск атомарной записи')
        # Check physical state against initial settings and actually executed events.
        expected_up=links[lid]['initial_up'];expected_cap=D(str(links[lid]['initial_capacity_bps']))
        for event in sorted([e for e in events.values() if e['result']=='executed'],key=lambda e:D(str(e['actual_time_s']))):
            if event['object_type']=='directed_links' and lid in event['object_ids']:
                t=D(str(event['actual_time_s']))
                need(not r['_a']<t<r['_b'],label+': интервал не разделён в момент изменения канала')
                if t<=r['_a']:
                    expected_up=event['changes'].get('link_up',expected_up)
                    expected_cap=D(str(event['changes'].get('capacity_bps',expected_cap)))
        need(r['_up']==expected_up and r['_cap']==expected_cap,label+': состояние/ёмкость не соответствуют паспорту и событиям')
        by_link[lid].append(r)
    grid=None
    for lid in links:
        cover(by_link[lid],cs,ce,'канал '+lid)
        by_link[lid].sort(key=lambda r:r['_a'])
        pairs=[(r['_a'],r['_b']) for r in by_link[lid]]
        if grid is None:grid=pairs
        need(pairs==grid,'У каналов должны совпадать границы общей временной сетки')
    edges={a for a,b in grid}|{b for a,b in grid}
    need(es in edges and ee in edges,'Границы окна оценки должны входить в сетку channels.csv')
    selected=meas['balance']['selected_link_ids']
    need(bool(selected) and len(set(selected))==len(selected) and set(selected).issubset(links),'Неверное множество каналов для балансировки')
    routes=tables['routes.csv'];by_flow=defaultdict(list);paths_seen={}
    for r in routes:
        label=f'routes.csv:{r["_line"]}'
        need(r['flow_id'] in flows,label+': неизвестный flow_id');identifier(r['route_set_id'],label+' route_set_id')
        r['_a']=number(r['time_start_s'],label+' start');r['_b']=number(r['time_end_s'],label+' end')
        need(cs<=r['_a']<r['_b']<=ce,label+': неверный интервал')
        need(r['route_state'] in ROUTE_STATES,label+': неверное состояние маршрута')
        try:r['_path']=json.loads(r['path_links'],parse_constant=reject_constant)
        except (ValueError,TypeError) as exc:raise ValidationError(label+': path_links должен содержать JSON-массив') from exc
        need(isinstance(r['_path'],list) and all(isinstance(x,str) and x in links for x in r['_path']),label+': неверные каналы в path_links')
        r['_share']=number(r['selection_share'],label+' share',D(0)) if r['selection_share']!='' else None
        if r['_share'] is not None:need(r['_share']<=1,label+': доля больше 1')
        if r['route_state'] in {'no_route','unknown'}:
            need(r['_path']==[] and r['path_id']=='',label+': для отсутствующего/неизвестного пути path должен быть [] и path_id пустым')
            need(r['_share']==(D(0) if r['route_state']=='no_route' else None),label+': неверная доля отсутствующего/неизвестного пути')
        else:
            identifier(r['path_id'],label+' path_id');need(bool(r['_path']),label+': отсутствует путь')
            verts=[links[r['_path'][0]]['node_from']]
            for lid in r['_path']:
                need(links[lid]['node_from']==verts[-1],label+': разорвана последовательность каналов')
                verts.append(links[lid]['node_to'])
            f=flows[r['flow_id']]
            need(verts[0]==f['source_node'],label+': путь начинается не в источнике потока')
            if r['route_state']=='installed':
                need(verts[-1]==f['destination_node'] and len(set(verts))==len(verts),label+': неверный конец установленного пути или петля')
            else:need(len(set(verts))<len(verts),label+': состояние loop без петли')
            key=(r['flow_id'],r['path_id']);p=tuple(r['_path'])
            need(key not in paths_seen or paths_seen[key]==p,label+': одинаковый path_id обозначает разные пути');paths_seen[key]=p
        if r['cause_event_id']:
            need(r['cause_event_id'] in events,label+': неизвестный cause_event_id')
            ev=events[r['cause_event_id']]
            need(ev['result']=='executed' and D(str(ev['actual_time_s']))<=r['_a'],label+': маршрут ссылается на ещё не выполненное событие')
        by_flow[r['flow_id']].append(r)
    for fid in flows:
        rs=by_flow[fid]
        if m['algorithm']['routing_mode']=='single_path_per_flow':
            cover(rs,cs,ce,'поток '+fid)
            for r in rs:
                if r['route_state'] in {'installed','loop'}:need(r['_share']==1,'При однопутевой маршрутизации доля выбранного пути должна быть 1')
        else:
            groups=defaultdict(list)
            for r in rs:groups[(r['_a'],r['_b'],r['route_set_id'])].append(r)
            representatives=[v[0] for v in groups.values()];cover(representatives,cs,ce,'поток '+fid)
            for group in groups.values():
                need(len({r['path_id'] for r in group})==len(group),'Повтор пути в одном наборе')
                if any(r['route_state'] in {'no_route','unknown'} for r in group):need(len(group)==1,'Отсутствующий маршрут нельзя смешивать с установленными')
                elif all(r['_share'] is not None for r in group):need(abs(sum(r['_share'] for r in group)-1)<=EPS,'Сумма долей путей не равна 1')
                else:warnings.append('Доли многопутевой передачи не полностью определены.')
        by_flow[fid].sort(key=lambda r:r['_a'])
    for c in meas['stability']['checks']:
        need(c['flow_id'] in flows,'Проверка устойчивости ссылается на неизвестный поток')
        a=number(c['time_start_s'],'stability start');h=number(c['horizon_s'],'stability horizon')
        need(h>0 and cs<=a<a+h<=ce,'Неверный горизонт проверки устойчивости')
    ad=meas['adaptivity'];h=number(ad['horizon_s'],'adaptivity horizon');conf=number(ad['confirmation_window_s'],'confirmation window')
    need(h>0 and conf>0,'Горизонты адаптивности должны быть положительными')
    for c in ad['checks']:
        need(c['flow_id'] in flows and c['event_id'] in events,'Некорректная ссылка испытания адаптивности')
    context={'manifest':m,'packets':packets,'by_link':by_link,'by_flow':by_flow,'events':events,
             'es':es,'ee':ee,'cs':cs,'ce':ce,'timeout':timeout,'grid':grid,'selected':selected}
    summary={'format_name':m['format_name'],'schema_version':m['schema_version'],'data_origin':m['data_origin'],
      'experiment_id':exp,'node_count':len(nodes),'directed_link_count':len(links),'flow_count':len(flows),
      'row_counts':{k:len(v) for k,v in tables.items()}}
    return summary,sorted(set(warnings)),context

def control_metrics(ctx: dict) -> dict:
    """Детерминированные частные проверки; не рассчитывают интегральный балл."""
    m=ctx['manifest'];es=ctx['es'];ee=ctx['ee'];timeout=ctx['timeout'];ce=ctx['ce']
    if (m['measurement']['time_base'] != 'shared_model_clock' or
        D(str(m['measurement']['clock_error_bound_s'])) != 0 or
        D(str(m['measurement']['route_time_error_bound_s'])) != 0 or
        m['measurement']['route_observation_mode'] != 'exact_state_changes'):
        return {'available':False,'reason':'Для неидеальной временной базы и периодического опроса нужны интервальные расчёты; вспомогательный скрипт их не реализует.'}
    if m['algorithm']['routing_mode']!='single_path_per_flow':
        return {'available':False,'reason':'Контроль R и T в этом вспомогательном скрипте реализован только для single_path_per_flow.'}
    rows=ctx['packets'];cohort=[r for r in rows if es<=r['_tx']<ee]
    if (not cohort or any(r['observation_status']!='complete' or (r['_rx'] is None and r['_obs']<r['_tx']+timeout) for r in cohort)
        or any(r['observation_status']!='complete' for rs in ctx['by_link'].values() for r in rs)
        or not m['export_status']['data_logging_complete']):
        return {'available':False,'reason':'Нет полного наблюдения для точного контрольного расчёта; не заменяйте отсутствующие значения нулями.'}
    delivered=[r for r in cohort if r['_rx'] is not None and r['_rx']-r['_tx']<=timeout]
    in_window=[r for r in rows if r['_rx'] is not None and es<=r['_rx']<ee]
    def route_at(flow: str,t: Decimal) -> dict | None:
        return next((r for r in ctx['by_flow'][flow] if r['_a']<=t<r['_b']),None)
    def physical(path: list[str],a: Decimal,b: Decimal) -> bool:
        if not path:return False
        return all(all(r['_up'] for r in ctx['by_link'][lid] if r['_a']<b and a<r['_b']) for lid in path)
    st=[]
    for c in m['measurement']['stability']['checks']:
        a=D(str(c['time_start_s']));b=a+D(str(c['horizon_s']));r=route_at(c['flow_id'],a)
        if r is None or r['route_state']=='unknown':return {'available':False,'reason':'Неизвестное состояние маршрута в проверке устойчивости.'}
        passed=bool(r and r['route_state']=='installed' and physical(r['_path'],a,b))
        st.append({'check_id':c['check_id'],'passed':passed})
    ad=m['measurement']['adaptivity'];h=D(str(ad['horizon_s']));confirm=D(str(ad['confirmation_window_s']));ats=[]
    for c in ad['checks']:
        e=ctx['events'][c['event_id']];a=D(str(e['actual_time_s']));flow=c['flow_id']
        if a+h+confirm>ce:return {'available':False,'reason':'Недостаточен горизонт наблюдения перестроения.'}
        rs=ctx['by_flow'][flow]
        if any(r['route_state']=='unknown' for r in rs if r['_a']<a+h+confirm and a<r['_b']):
            return {'available':False,'reason':'Неизвестная история маршрутов в испытании адаптивности.'}
        candidates={a}
        candidates.update(r['_a'] for r in rs if a<=r['_a']<=a+h)
        candidates.update(x for pair in ctx['grid'] for x in pair if a<=x<=a+h)
        tau=None
        for t in sorted(candidates):
            r=route_at(flow,t)
            if not r or r['route_state']!='installed':continue
            same=all(s['route_state']=='installed' and s['_path']==r['_path'] for s in rs if s['_a']<t+confirm and t<s['_b'])
            if same and physical(r['_path'],t,t+confirm):tau=t-a;break
        ats.append({'check_id':c['check_id'],'time_s':float(tau) if tau is not None else None,
                    'restricted_time_s':float(min(tau,h) if tau is not None else h),'completed':tau is not None})
    jtotal=D(0);undefined=[]
    for a,b in ctx['grid']:
        if not es<=a<b<=ee:continue
        loads=[]
        for lid in ctx['selected']:
            r=next(r for r in ctx['by_link'][lid] if r['_a']==a and r['_b']==b)
            if r['_up']:loads.append(D(8*r['_tx_data_bytes'])/(r['_cap']*(b-a)))
        sq=sum(x*x for x in loads)
        if not loads or sq==0:undefined.append([float(a),float(b)]);continue
        j=sum(loads)**2/(len(loads)*sq);jtotal+=(b-a)*j
    routing=sum(r['_tx_routing_bytes'] for rs in ctx['by_link'].values() for r in rs if es<=r['_a']<r['_b']<=ee)
    data_main=sum(r['_tx_data_bytes'] for rs in ctx['by_link'].values() for r in rs if es<=r['_a']<r['_b']<=ee)
    data_all=sum(r['_tx_data_bytes'] for rs in ctx['by_link'].values() for r in rs)
    return {'available':True,'sent_packets':len(cohort),'delivered_within_timeout':len(delivered),
       'lost_after_timeout':len(cohort)-len(delivered),'received_in_evaluation_window':len(in_window),
       'received_after_evaluation_window':sum(r['_rx'] is not None and r['_rx']>=ee for r in cohort),
       'payload_received_in_evaluation_window_bytes':sum(r['_size'] for r in in_window),
       'mean_delay_s':float(sum(r['_rx']-r['_tx'] for r in delivered)/len(delivered)) if delivered else None,
       'goodput_bps':float(D(8*sum(r['_size'] for r in in_window))/(ee-es)),
       'loss_ratio':float(D(len(cohort)-len(delivered))/len(cohort)),
       'balance_index':None if undefined else float(jtotal/(ee-es)),
       'balance_undefined_intervals_s':undefined,
       'stability_ratio':sum(c['passed'] for c in st)/len(st) if st else None,
       'stability_checks':st,'adaptivity_checks':ats,
       'restricted_mean_reroute_time_s':sum(c['restricted_time_s'] for c in ats)/len(ats) if ats else None,
       'routing_bytes_evaluation_window':routing,'channel_data_bytes_evaluation_window':data_main,
       'channel_data_bytes_full_capture':data_all,'integral_score':None,
       'integral_score_note_ru':'Балльные шкалы и веса не входят в эталон выгрузки; итоговый балл намеренно не назначен.'}

def compare_reference(actual: dict, expected: dict, path: str='') -> None:
    if isinstance(expected,dict):
        need(isinstance(actual,dict),path+': ожидался объект')
        for k,v in expected.items():need(k in actual,path+'/'+k+': нет поля');compare_reference(actual[k],v,path+'/'+k)
    elif isinstance(expected,list):
        need(isinstance(actual,list) and len(actual)==len(expected),path+': различаются списки')
        for i,(a,e) in enumerate(zip(actual,expected)):compare_reference(a,e,path+f'/{i}')
    elif isinstance(expected,(int,float)) and not isinstance(expected,bool):
        need(isinstance(actual,(int,float)) and not isinstance(actual,bool) and math.isclose(actual,expected,rel_tol=1e-10,abs_tol=1e-12),path+f': {actual!r} != {expected!r}')
    else:need(actual==expected,path+f': {actual!r} != {expected!r}')

def main() -> int:
    ap=argparse.ArgumentParser(description='Проверка формата и согласованности 4 файлов. Реальные значения не обязаны совпадать с искусственным примером.')
    ap.add_argument('folder',type=Path,help='Папка, содержащая только experiment.json, packets.csv, routes.csv, channels.csv')
    ap.add_argument('--reference-check',action='store_true',help='Дополнительно сравнить расчёт с данным искусственным контрольным сценарием; не применять к произвольному реальному опыту')
    ap.add_argument('--report',type=Path,help='Сохранить отчёт проверки вне папки четырёхфайловой выгрузки')
    args=ap.parse_args()
    try:
        summary,warnings,ctx=validate(args.folder)
        metrics=control_metrics(ctx)
        if args.reference_check:
            expected=read_json(Path(__file__).with_name('expected_checks.json'))
            compare_reference({'summary':summary,'metrics':metrics},expected)
        result={'status':'PASS','warnings':warnings,'summary':summary,'metrics':metrics,
                'scope_ru':'Синтаксис, основные поля, ссылки, интервалы, целостность и контрольные частные расчёты. Не доказывает физическую точность реального опыта или валидность интегральной модели.'}
        code=0
    except (ValidationError,KeyError,TypeError,ValueError,OSError,csv.Error) as exc:
        result={'status':'FAIL','error':str(exc)};code=1
    text=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)
    if args.report:
        need(args.report.parent.resolve()!=args.folder.resolve(),'Отчёт проверки нельзя записывать пятым файлом в папку выгрузки')
        args.report.write_text(text+'\n',encoding='utf-8')
    print(text)
    return code

if __name__=='__main__':
    raise SystemExit(main())

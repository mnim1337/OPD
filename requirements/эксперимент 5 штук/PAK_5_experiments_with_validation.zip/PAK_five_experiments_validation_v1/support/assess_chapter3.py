"""Исполняемый проверочный расчёт по последней главе 3, а не старая модель v2.
Четыре файла schema 1.0.0; исходный валидатор не изменён. P_ad — обычное
среднее измеренного времени; цензурированные времена сохраняются границами.
Поддерживаемый измерительный профиль: единые точные модельные часы,
однопутевые состояния, нумерованные пакеты без транспортных повторов.
"""
from __future__ import annotations
import argparse, hashlib, json
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path
from typing import Any
import validate_export as schema
getcontext().prec=50
D=Decimal
KEYS=['P_zad','P_pr','P_pot','P_bal','P_ust','P_ad','P_res']
SYMBOLS=['P_зад(A)','P_пр(A)','P_пот(A)','P_бал(A)','P_уст(A)','P_ад(A)','P_рес(A)']
UNITS=['s','bit/s','1','1','1','s','byte']
DIRECTIONS=['min','max','min','max','max','min','min']

class ModelError(ValueError):pass

def need(v: bool,msg: str):
    if not v:raise ModelError(msg)

def dec(x):return x if isinstance(x,D) else D(str(x))

def exact(x, **kw):
    x=dec(x);return dict(status='exact',value=x,lower=x,upper=x,upper_unbounded=False,**kw)

def bounded(lo,hi,**kw):
    lo=dec(lo);hi=None if hi is None else dec(hi)
    if hi is not None and lo==hi:return exact(lo,**kw)
    return dict(status='lower_bound' if hi is None else 'bounded',value=None,lower=lo,upper=hi,upper_unbounded=hi is None,**kw)

def undefined(reason):return dict(status='undefined',value=None,lower=None,upper=None,upper_unbounded=False,reason_ru=reason)

def physical(ctx,path,a,b):
    if not path:return False
    if a<ctx['cs'] or b>ctx['ce'] or b<=a:return None
    unknown=False
    for lid in path:
        rows=[r for r in ctx['by_link'][lid] if r['_a']<b and a<r['_b']]
        if not rows:return None
        for r in rows:
            if r['observation_status']!='complete':unknown=True
            elif not r['_up']:return False
    return None if unknown else True

def route_at(ctx,flow,t):
    return next((r for r in ctx['by_flow'][flow] if r['_a']<=t<r['_b']),None)

def connected(ctx,flow,t):
    m=ctx['manifest'];ff=next(f for f in m['traffic']['flows'] if f['flow_id']==flow)
    links={x['link_id']:x for x in m['network']['links']};adj=defaultdict(list)
    for lid,rs in ctx['by_link'].items():
        row=next((r for r in rs if r['_a']<=t<r['_b']),None)
        if row is None or row['observation_status']!='complete':return None
        if row['_up']:adj[links[lid]['node_from']].append(links[lid]['node_to'])
    found={ff['source_node']};todo=list(found)
    while todo:
        v=todo.pop()
        for w in adj[v]:
            if w not in found:found.add(w);todo.append(w)
    return ff['destination_node'] in found

def compute(ctx):
    m=ctx['manifest'];meas=m['measurement'];es,ee=ctx['es'],ctx['ee'];T=ee-es
    need(meas['time_base']=='shared_model_clock' and dec(meas['clock_error_bound_s'])==0,
         'Для данного исполняемого расчёта нужна общая точная временная база; погрешности требуют интервальной обработки первичных моментов.')
    need(meas['route_observation_mode']=='exact_state_changes' and dec(meas['route_time_error_bound_s'])==0,
         'Периодический опрос маршрутов не выдаётся за точные изменения состояния.')
    need(m['algorithm']['routing_mode']=='single_path_per_flow','Многопутевой профиль в данной версии не реализован.')
    for f in m['traffic']['flows']:
        pp=f['packetization'];need(not pp.get('fragmentation') and not pp.get('transport_retransmission'),
            'Для фрагментации или повторов нужен отдельный идентификатор уникальной полезной информации.')
    packets=ctx['packets'];cohort=[r for r in packets if es<=r['_tx']<ee]
    need(cohort,'Нет отправок в основном окне; полная модель не определена.')
    # The provided logger flag covers all streams, so do not claim complete packet cohort if records were lost.
    if (m['export_status']['lost_log_records'] or not m['export_status']['data_logging_complete'] or m['export_status']['logging_gaps']):
        raise ModelError('Есть потерянные записи: полнота множества отправок не подтверждена.')
    timely=[];lost=[];unknown=[]
    for p in cohort:
        if p['observation_status']!='complete':unknown.append(p)
        elif p['_rx'] is not None and p['_rx']-p['_tx']<=ctx['timeout']:timely.append(p)
        elif p['_rx'] is not None or p['_obs']>=p['_tx']+ctx['timeout']:lost.append(p)
        else:unknown.append(p)
    out={}
    if unknown:out['P_zad']=bounded(0,ctx['timeout'],reason_ru='Не установлен полный состав своевременных доставок; границы условны при наличии доставок.') if timely else undefined('Не подтверждено наличие доставок для определения условной средней задержки.')
    elif timely:out['P_zad']=exact(sum((p['_rx']-p['_tx'] for p in timely),D(0))/len(timely))
    else:out['P_zad']=undefined('Ни один пакет не доставлен в срок; средняя задержка не существует.')
    out['P_pot']=bounded(D(len(lost))/len(cohort),D(len(lost)+len(unknown))/len(cohort))
    received=[p for p in packets if p['observation_status']=='complete' and p['_rx'] is not None and es<=p['_rx']<ee]
    gu=[p for p in packets if p['observation_status']!='complete' and p['_tx']<ee]
    goodbytes=sum(p['_size'] for p in received)
    out['P_pr']=bounded(D(8*goodbytes)/T,D(8*(goodbytes+sum(p['_size'] for p in gu)))/T)
    # Nonconstant counters cannot be split proportionally in time; source validator enforces shared boundaries.
    balance=[];jsum_lo=D(0);jsum_hi=D(0);undefined_bins=[]
    for a,b in ctx['grid']:
        if not es<=a<b<=ee:continue
        loads=[];uncertain=False
        for lid in ctx['selected']:
            r=next(x for x in ctx['by_link'][lid] if x['_a']==a and x['_b']==b)
            if r['observation_status']!='complete' or r['_tx_data_bytes'] is None:uncertain=True
            if r['_up'] and r['_tx_data_bytes'] is not None:
                loads.append(D(8*r['_tx_data_bytes'])/(r['_cap']*(b-a)))
        if uncertain:
            lo,hi=D(0),D(1);val=None
        elif not loads or not sum(x*x for x in loads):
            undefined_bins.append([a,b]);balance.append(dict(start=a,end=b,value=None,reason='zero_data_or_no_active_links'));continue
        else:
            val=sum(loads)**2/(len(loads)*sum(x*x for x in loads));lo=hi=val
        jsum_lo+=(b-a)*lo;jsum_hi+=(b-a)*hi
        balance.append(dict(start=a,end=b,value=val,lower=lo,upper=hi))
    out['P_bal']=undefined('Индекс Джейна не определён в одном или нескольких интервалах; интервалы не удалены.') if undefined_bins else bounded(jsum_lo/T,jsum_hi/T)
    # Fixed original route survival, not persistence of the route table entry.
    st=[]
    for c in meas['stability']['checks']:
        a=dec(c['time_start_s']);b=a+dec(c['horizon_s']);r=route_at(ctx,c['flow_id'],a)
        if r is None or r['route_state']=='unknown':passed=None
        elif r['route_state']!='installed':passed=False
        else:passed=physical(ctx,r['_path'],a,b)
        st.append(dict(check_id=c['check_id'],passed=passed))
    if not st:out['P_ust']=undefined('Не назначены проверки сохранения маршрутов.')
    else:
        ntrue=sum(x['passed'] is True for x in st);nunknown=sum(x['passed'] is None for x in st)
        out['P_ust']=bounded(D(ntrue)/len(st),D(ntrue+nunknown)/len(st))
    # Adaptive reconstruction according to section 3.3.6; never use restricted mean as P_ad.
    ad=meas['adaptivity'];h=dec(ad['horizon_s']);conf=dec(ad['confirmation_window_s']);ats=[];ineligible=[]
    for c in ad['checks']:
        ev=ctx['events'][c['event_id']];a=dec(ev['actual_time_s']);fid=c['flow_id'];rs=ctx['by_flow'][fid]
        old=next((r for r in reversed(rs) if r['_a']<a<=r['_b']),None)
        eps=dec(meas['timestamp_resolution_s'])
        if old is None or old['route_state']!='installed' or physical(ctx,old['_path'],a-eps,a) is not True:
            ineligible.append(dict(check_id=c['check_id'],reason_ru='До события не подтверждён работоспособный установленный путь.'));continue
        if physical(ctx,old['_path'],a,a+eps) is not False:
            ineligible.append(dict(check_id=c['check_id'],reason_ru='Событие не нарушило прежний путь; нельзя автоматически записать нулевую адаптивность.'));continue
        horizon=min(a+h+conf,ctx['ce'])
        states=sorted({a}|{x for ab in ctx['grid'] for x in ab if a<=x<horizon})
        conn=[connected(ctx,fid,t) for t in states]
        if any(x is not True for x in conn):
            ineligible.append(dict(check_id=c['check_id'],reason_ru='Альтернативная физическая связность не подтверждена на горизонте.'));continue
        candidates={a}
        candidates.update(x for r in rs for x in [r['_a'],r['_b']] if a<=x<=a+h)
        candidates.update(x for ab in ctx['grid'] for x in ab if a<=x<=a+h)
        tau=None;history_unknown=False
        for t in sorted(candidates):
            if t+conf>ctx['ce']:continue
            r=route_at(ctx,fid,t)
            if r is None or r['route_state']=='unknown':history_unknown=True;continue
            if r['route_state']!='installed':continue
            relevant=[x for x in rs if x['_a']<t+conf and t<x['_b']]
            if any(x['route_state']=='unknown' for x in relevant):history_unknown=True;continue
            same=all(x['route_state']=='installed' and x['_path']==r['_path'] for x in relevant)
            phys=physical(ctx,r['_path'],t,t+conf)
            if phys is None:history_unknown=True
            if same and phys is True:tau=t-a;break
        if tau is not None and not history_unknown:
            ats.append(dict(check_id=c['check_id'],status='completed',time_s=tau,lower_s=tau,upper_s=tau,lower_open=False))
        else:
            full=ctx['ce']>=a+h+conf and not history_unknown
            lower=h if full else (D(0) if history_unknown else max(D(0),min(h,ctx['ce']-a-conf)))
            ats.append(dict(check_id=c['check_id'],status='not_completed_within_horizon' if full else 'incomplete_history',
                time_s=None,lower_s=lower,upper_s=None,lower_open=full))
    if not ad['checks']:out['P_ad']=undefined('Нет назначенных задач перестроения.')
    elif ineligible:out['P_ad']=undefined('Не все назначенные события соответствуют области применимости показателя. Состав выборки не сокращён.')
    elif all(x['status']=='completed' for x in ats):out['P_ad']=exact(sum((x['time_s'] for x in ats),D(0))/len(ats))
    else:out['P_ad']=bounded(sum((x['lower_s'] for x in ats),D(0))/len(ats),None,lower_open=any(x['lower_open'] for x in ats),reason_ru='Неизмеренное завершение не заменено горизонтом.')
    o_lo=D(0);o_hi=D(0)
    atom=dec(meas['channel_max_atomic_packet_bytes'])
    for rs in ctx['by_link'].values():
        for r in rs:
            if not es<=r['_a']<r['_b']<=ee:continue
            if r['observation_status']=='complete' and r['_tx_routing_bytes'] is not None:
                o_lo+=r['_tx_routing_bytes'];o_hi+=r['_tx_routing_bytes']
            else:o_hi+=r['_cap']*(r['_b']-r['_a'])/8+atom if r['_up'] else 0
    out['P_res']=bounded(o_lo,o_hi)
    for key,symbol,unit in zip(KEYS,SYMBOLS,UNITS):out[key].update(symbol=symbol,unit=unit)
    detail=dict(sent_packets=len(cohort),timely_received=len(timely),confirmed_lost=len(lost),unknown_packets=len(unknown),
        received_in_window=len(received),received_after_window=sum(p['_rx'] is not None and p['_rx']>=ee for p in cohort),
        payload_received_in_window=goodbytes,drop_reasons=dict(Counter(p['drop_reason'] for p in cohort if p['drop_reason'])),
        balance_intervals=balance,balance_undefined_intervals=undefined_bins,stability_checks=st,
        adaptivity_checks=ats,adaptivity_ineligible=ineligible)
    return out,detail

def validate_profile(profile):
    need(profile.get('profile_status')=='demonstration_not_empirically_calibrated','Профиль должен явно обозначать статус калибровки.')
    metrics=profile['metrics'];need(list(metrics)==KEYS,'Требуются семь показателей в порядке главы 2.')
    weights=[]
    for key,direction in zip(KEYS,DIRECTIONS):
        mm=metrics[key];w=dec(mm['weight']);need(w>0,'Все семь весов должны быть положительными.');weights.append(w)
        pts=[(dec(x),dec(y)) for x,y in mm['points']]
        need(len(pts)>=2 and all(pts[k][0]<pts[k+1][0] for k in range(len(pts)-1)),'Опоры должны строго возрастать.')
        need(all(0<=y<=1 for x,y in pts),'Оценки должны принадлежать [0;1].')
        need(mm['direction']==direction,'Направление отличается от главы 2.')
        ys=[y for x,y in pts];expected=sorted(ys,reverse=direction=='min')
        need(ys==expected and ys[0]==(1 if direction=='min' else 0) and ys[-1]==(0 if direction=='min' else 1),'Неверная монотонность или крайние опоры.')
    need(abs(sum(weights)-1)<D('1e-20'),'Сумма весов должна равняться единице.')

def norm(value,mm):
    pts=[(dec(x),dec(y)) for x,y in mm['points']]
    if value is None:return pts[-1][1]  # positive infinity for an existing lower-bounded quantity
    value=dec(value)
    if value<=pts[0][0]:return pts[0][1]
    if value>=pts[-1][0]:return pts[-1][1]
    for (x0,y0),(x1,y1) in zip(pts,pts[1:]):
        if x0<=value<=x1:return y0+(y1-y0)*(value-x0)/(x1-x0)
    raise ModelError('Не удалось найти участок шкалы.')

def score(metrics,profile):
    validate_profile(profile);normal={};total_lo=D(0);total_hi=D(0);blocked=[]
    for key in KEYS:
        p=metrics[key];mm=profile['metrics'][key];w=dec(mm['weight'])
        if p['status']=='undefined':normal[key]=dict(status='undefined',reason_ru=p.get('reason_ru'));blocked.append(key);continue
        ends=[norm(p['lower'],mm),norm(p['upper'],mm)];lo,hi=min(ends),max(ends)
        normal[key]=dict(status='exact' if lo==hi else 'bounded',value=lo if lo==hi else None,
            lower=lo,upper=hi,weight=w,contribution_lower=100*w*lo,contribution_upper=100*w*hi)
        total_lo+=100*w*lo;total_hi+=100*w*hi
    if blocked:integral=dict(status='undefined',value=None,lower=None,upper=None,blocked_metrics=blocked)
    else:integral=bounded(total_lo,total_hi)
    groups={}
    for idx,group in enumerate([KEYS[:3],[KEYS[3]],KEYS[4:6],[KEYS[6]]],1):
        wg=sum(dec(profile['metrics'][k]['weight']) for k in group)
        if any(k in blocked for k in group):groups[f'I_{idx}']=undefined('Есть неопределённый показатель группы.')
        else:groups[f'I_{idx}']=bounded(sum(normal[k]['contribution_lower'] for k in group)/wg,
                                     sum(normal[k]['contribution_upper'] for k in group)/wg)
    return normal,groups,integral

def json_ready(x):
    if isinstance(x,D):return float(x)
    if isinstance(x,dict):return {str(k):json_ready(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [json_ready(v) for v in x]
    return x

def assess(folder: Path,profile: dict):
    summary,warnings,ctx=schema.validate(folder)
    metrics,detail=compute(ctx);normal,groups,integral=score(metrics,profile)
    origin=ctx['manifest']['data_origin']
    return json_ready(dict(model_version='chapter3-aligned-validation-1.0',experiment_id=summary['experiment_id'],
        source_status=origin,empirically_validated=False,format_status='PASS',warnings=warnings,
        input_summary=summary,profile_id=profile['profile_id'],profile_status=profile['profile_status'],
        metrics=metrics,normalized_metrics=normal,group_scores=groups,integral_score=integral,diagnostics=detail,
        input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir()) if p.is_file()}))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('experiment',type=Path);ap.add_argument('profile',type=Path);ap.add_argument('--out',type=Path);args=ap.parse_args()
    try:
        res=assess(args.experiment,json.loads(args.profile.read_text(encoding='utf-8')))
        txt=json.dumps(res,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
        if args.out:args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(txt,encoding='utf-8')
        else:print(txt,end='')
    except (ValueError,KeyError,TypeError) as e:raise SystemExit('ОШИБКА: '+str(e))
if __name__=='__main__':main()

"""Детерминированные контрольные данные формата PAK_ROUTING_EXPORT_4F 1.0.0.
Это не ПАК и не модель орбит: небольшой генератор с явными путями, FIFO,
ограничением очередей и передачей пакетов. Задержки реакции и служебные
сообщения заданы как тестовые условия, не как свойства реальных протоколов.
Все внутренние времена — целые наносекунды. В каждой папке ровно 4 файла.
"""
from __future__ import annotations
import argparse, bisect, copy, csv, hashlib, heapq, json
from collections import defaultdict, deque
from pathlib import Path

HERE = Path(__file__).resolve().parent
NS = 1_000_000_000
SPECS = [
 dict(id='EXP01_REACTIVE_4', n=4, pps=20, mode='reactive', reaction_ns=600_000_000,
      control_period_ns=NS, control_bytes=128, buffer=10280, restore=True,
      bidirectional_failure=True, scenario='SC_DIAMOND4_LOW_FAILURE', group='PAIR_4_LOW',
      title='4 спутника: реактивное перестроение за 0,6 с'),
 dict(id='EXP02_FAST_4', n=4, pps=20, mode='fast_backup', reaction_ns=100_000_000,
      control_period_ns=250_000_000, control_bytes=128, buffer=10280, restore=True,
      bidirectional_failure=True, scenario='SC_DIAMOND4_LOW_FAILURE', group='PAIR_4_LOW',
      title='4 спутника: переключение на резерв за 0,1 с'),
 dict(id='EXP03_REACTIVE_12_LOW', n=12, pps=20, mode='reactive', reaction_ns=600_000_000,
      control_period_ns=NS, control_bytes=128, buffer=10280, restore=True,
      bidirectional_failure=True, scenario='SC_DIAMOND12_LOW_FAILURE', group='SCALE12_LOW',
      title='12 спутников: низкая нагрузка, ограниченный резервный канал'),
 dict(id='EXP04_REACTIVE_12_HIGH', n=12, pps=80, mode='reactive', reaction_ns=600_000_000,
      control_period_ns=NS, control_bytes=128, buffer=10280, restore=True,
      bidirectional_failure=True, scenario='SC_DIAMOND12_HIGH_FAILURE', group='SCALE12_HIGH',
      title='12 спутников: повышенная нагрузка и переполнение очередей'),
 dict(id='EXP05_STATIC_24_NO_RECOVERY', n=24, pps=20, mode='static', reaction_ns=None,
      control_period_ns=2*NS, control_bytes=64, buffer=10280, restore=False,
      bidirectional_failure=False, scenario='SC_DIAMOND24_STATIC_FAILURE', group='BOUNDARY24',
      title='24 спутника: незавершённое перестроение одного направления'),
]

def fmt(t: int) -> str:
    return f'{t//NS}.{t%NS:09d}'

def dump_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8', newline='\n')

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def make_topology(n: int):
    sat=lambda k:f'S{k:02d}'
    main=[sat(1),*[sat(i) for i in range(2,n//2+1)],sat(n)]
    backup=[sat(1),*[sat(i) for i in range(n//2+1,n)],sat(n)]
    chains=[['G01',*main,'G02'], ['G01',*backup,'G02']]
    nodes=[dict(node_id='G01',node_type='ground_station',plane_id=None,initial_up=True)]
    nodes += [dict(node_id=sat(i),node_type='satellite',plane_id='PL01',initial_up=True) for i in range(1,n+1)]
    nodes += [dict(node_id='G02',node_type='ground_station',plane_id=None,initial_up=True)]
    edges={}
    def lid(a,b):return f'L_{a}_{b}'
    for ci,chain in enumerate(chains):
        for a,b in zip(chain,chain[1:]):
            ground=a.startswith('G') or b.startswith('G')
            for u,v in [(a,b),(b,a)]:
                k=lid(u,v)
                prop_ns=10_000_000 if ground else (5_000_000 if ci==0 else 7_500_000)
                cap=2_000_000
                if n==12 and {u,v}=={sat(n-1),sat(n)}:cap=256_000
                edges[k]=dict(link_id=k,node_from=u,node_to=v,interface_from=f'{u}_TO_{v}',
                    interface_to=f'{v}_FROM_{u}',link_type='ground_space' if ground else 'intersatellite',
                    initial_up=True,initial_capacity_bps=cap,initial_propagation_delay_s=prop_ns/NS,
                    initial_routing_cost=prop_ns/NS,resource_allocation='independent_direction',_prop_ns=prop_ns)
    path=lambda chain:[lid(a,b) for a,b in zip(chain,chain[1:])]
    paths={'F01':dict(primary=path(chains[0]),backup=path(chains[1])),
           'F02':dict(primary=path(list(reversed(chains[0]))),backup=path(list(reversed(chains[1]))))}
    bad=[lid(sat(n//2),sat(n)),lid(sat(n),sat(n//2))]
    return nodes,dict(sorted(edges.items())),paths,bad

def generate_one(spec: dict, dest: Path, ledger_dir: Path) -> dict:
    template=json.loads((HERE/'reference_template/experiment.json').read_text(encoding='utf-8'))
    m=copy.deepcopy(template);exp=spec['id'];n=spec['n']
    nodes,links,paths,bad=make_topology(n)
    failed=bad if spec['bidirectional_failure'] else bad[:1]
    fail=4*NS;restore=8*NS if spec['restore'] else None
    end=12*NS;capture=14*NS;dt=NS//2
    events=[dict(event_id='E01',event_type='link_down',object_type='directed_links',object_ids=failed,
        scheduled_time_s=3.98,actual_time_s=4.0,result='executed',changes={'link_up':False,'capacity_bps':0})]
    if restore is not None:
        events.append(dict(event_id='E02',event_type='link_up',object_type='directed_links',object_ids=failed,
            scheduled_time_s=7.98,actual_time_s=8.0,result='executed',changes={'link_up':True,'capacity_bps':2_000_000}))
    def is_up(lid,t):return not(lid in failed and t>=fail and (restore is None or t<restore))
    def span_up(lid,a,b):
        if not is_up(lid,a):return False
        return not(lid in failed and a<fail<b)
    def shortest(t,source,destnode):
        # Actual shortest path calculation for this abstract graph; no optimization at export time.
        adj=defaultdict(list)
        for lid,e in links.items():
            if is_up(lid,t):adj[e['node_from']].append((e['node_to'],lid,e['_prop_ns']))
        heap=[(0,(),source)];best={source:0}
        while heap:
            cost,p,u=heapq.heappop(heap)
            if cost!=best[u]:continue
            if u==destnode:return list(p)
            for v,lid,w in sorted(adj[u]):
                nc=cost+w
                if nc<best.get(v,10**30):best[v]=nc;heapq.heappush(heap,(nc,p+(lid,),v))
        return []
    transitions={}
    for fid in paths:
        s,d=('G01','G02') if fid=='F01' else ('G02','G01')
        initial=shortest(0,s,d)
        assert initial==paths[fid]['primary']
        tr=[(0,initial,'')]
        affected=any(l in failed for l in initial)
        if affected and spec['mode']!='static':
            withdrawal=40_000_000 if spec['mode']=='fast_backup' else 200_000_000
            tr.append((fail+withdrawal,[],'E01'))
            path=paths[fid]['backup'] if spec['mode']=='fast_backup' else shortest(fail+spec['reaction_ns'],s,d)
            assert path and all(is_up(l,fail+spec['reaction_ns']) for l in path)
            tr.append((fail+spec['reaction_ns'],path,'E01'))
            if restore is not None:tr.append((restore+200_000_000,shortest(restore+200_000_000,s,d),'E02'))
        transitions[fid]=tr
    def route_at(fid,t):
        return next(path for tt,path,ev in reversed(transitions[fid]) if tt<=t)
    heap=[];counter=0;trace=[];txledger=[];reservation={lid:deque() for lid in links}
    packets={};processing=100_000
    def push(t,kind,body):
        nonlocal counter
        counter+=1;heapq.heappush(heap,(t,counter,kind,body))
    def trace_event(kind,t,**kwargs):trace.append(dict(kind=kind,time_ns=t,**kwargs))
    for fid,tr in transitions.items():
        for t,path,event in tr:trace_event('route_install',t,flow_id=fid,path=path,event_id=event)
    count=12*spec['pps'];interval=NS//spec['pps'];first=interval//2
    for fid in ['F01','F02']:
        for k in range(count):
            t=first+k*interval
            assert t<end
            pid=f'{fid}_P{k+1:06d}';push(t,'app_tx',(fid,pid,1000))
    # Test-defined control datagrams share channel FIFO with data. They do not model OSPF handshakes.
    for lid in links:
        t=100_000_000
        while t<capture:
            push(t,'control',(lid,spec['control_bytes']));t+=spec['control_period_ns']
    if spec['mode']!='static':
        for et in [fail]+([restore] if restore is not None else []):
            for lid in links:push(et+10_000_000,'control',(lid,256))
    def service(lid,t,size,category,pid=''):
        q=reservation[lid]
        while q and q[0][0]<=t:q.popleft()
        if not is_up(lid,t):return None,'link_unavailable'
        if sum(b for e,b in q)+size>spec['buffer']:return None,'queue_overflow'
        start=max(t,q[-1][0] if q else t)
        serial=(8*size*NS+links[lid]['initial_capacity_bps']-1)//links[lid]['initial_capacity_bps']
        stop=start+serial
        if not span_up(lid,start,stop):return None,'link_outage_before_serialization_complete'
        if stop>=capture:return None,'observation_ended'
        q.append((stop,size))
        txledger.append(dict(link_id=lid,start_ns=start,end_ns=stop,bytes=size,category=category,packet_id=pid))
        trace_event('link_tx_complete',stop,link_id=lid,start_ns=start,bytes=size,category=category,packet_id=pid)
        return stop+links[lid]['_prop_ns'],None
    while heap:
        t,_,kind,body=heapq.heappop(heap)
        if t>=capture:continue
        if kind=='control':
            lid,size=body;service(lid,t,size,'routing')
        elif kind=='app_tx':
            fid,pid,payload=body
            packets[pid]=dict(flow_id=fid,packet_id=pid,tx=t,rx=None,size=payload,drop='')
            trace_event('app_tx',t,flow_id=fid,packet_id=pid,payload_bytes=payload)
            path=route_at(fid,t)
            if not path:
                packets[pid]['drop']='no_route';trace_event('drop',t,packet_id=pid,reason='no_route')
            else:push(t+processing,'hop',(pid,list(path),0))
        elif kind=='hop':
            pid,path,k=body;p=packets[pid]
            arrival,reason=service(path[k],t,p['size']+28,'data',pid)
            if reason:
                p['drop']=reason;trace_event('drop',t,packet_id=pid,reason=reason)
            elif k+1==len(path):push(arrival,'app_rx',pid)
            else:push(arrival+processing,'hop',(pid,path,k+1))
        elif kind=='app_rx':
            p=packets[body];p['rx']=t;trace_event('app_rx',t,packet_id=body,payload_bytes=p['size'])
    packet_rows=[]
    for p in sorted(packets.values(),key=lambda p:(p['tx'],p['flow_id'],p['packet_id'])):
        packet_rows.append(dict(experiment_id=exp,flow_id=p['flow_id'],packet_id=p['packet_id'],
            tx_time_s=fmt(p['tx']),rx_time_s='' if p['rx'] is None else fmt(p['rx']),payload_bytes=p['size'],
            rx_copy_count=0 if p['rx'] is None else 1,observed_until_s=fmt(capture),observation_status='complete',
            drop_reason=p['drop']))
    route_rows=[]
    for fid,tr in transitions.items():
        known_paths={}
        for k,(t,path,ev) in enumerate(tr):
            key=tuple(path)
            if path and key not in known_paths:known_paths[key]=f'{fid}_PATH{len(known_paths)+1:02d}'
            stop=tr[k+1][0] if k+1<len(tr) else capture
            route_rows.append(dict(experiment_id=exp,flow_id=fid,route_set_id=f'{fid}_RS{k+1:02d}',
                path_id=known_paths.get(key,''),time_start_s=fmt(t),time_end_s=fmt(stop),
                path_links=json.dumps(path,separators=(',',':')),route_state='installed' if path else 'no_route',
                selection_share=1 if path else 0,cause_event_id=ev))
    route_rows.sort(key=lambda r:(r['time_start_s'],r['flow_id']))
    grid=list(range(0,capture+1,dt));counts=defaultdict(lambda:defaultdict(int))
    for x in txledger:
        idx=bisect.bisect_right(grid,x['end_ns'])-1
        counts[(x['link_id'],idx)][x['category']]+=x['bytes']
    channel_rows=[]
    for k,(a,b) in enumerate(zip(grid,grid[1:])):
        for lid,e in links.items():
            up=is_up(lid,a);cc=counts[(lid,k)]
            channel_rows.append(dict(experiment_id=exp,link_id=lid,time_start_s=fmt(a),time_end_s=fmt(b),
                link_up=int(up),capacity_bps=e['initial_capacity_bps'] if up else 0,
                propagation_delay_s=fmt(e['_prop_ns']),routing_cost=f"{e['initial_routing_cost']:.9f}",
                tx_data_bytes=cc['data'],tx_routing_bytes=cc['routing'],tx_other_bytes=0,observation_status='complete',
                queue_mean_bytes='',queue_max_bytes='',drop_data_packets=''))
    m['data_origin']='synthetic_reference';m['description_ru']='СИНТЕТИЧЕСКИЙ КОНТРОЛЬНЫЙ ОПЫТ. '+spec['title']+'. Не результат ПАК и не измерение реального протокола.'
    m['experiment_id']=exp;m['scenario_id']=spec['scenario'];m['repeat_id']=1
    aid={'reactive':'SYNTHETIC_REACTIVE_SPF','fast_backup':'SYNTHETIC_FAST_BACKUP','static':'SYNTHETIC_STATIC'}[spec['mode']]
    m['algorithm']=dict(algorithm_id=aid,name_ru=spec['title'],implementation_version='fixture-builder-1.0',
        routing_mode='single_path_per_flow',implementation_sha256=sha(Path(__file__)),
        settings=dict(selection_rule='minimum_sum_propagation_delay' if spec['mode']!='static' else 'initial_minimum_delay_path_without_updates',
           source_routing=True,reaction_time_s=None if spec['reaction_ns'] is None else spec['reaction_ns']/NS,
           withdrawal_after_failure_s=None if spec['mode']=='static' else (.04 if spec['mode']=='fast_backup' else .2),
           control_datagram_bytes=spec['control_bytes'],control_period_s=spec['control_period_ns']/NS,
           restore_recompute_delay_s=None if spec['mode']=='static' else .2),
        settings_completeness='complete_for_synthetic_fixture',
        note_ru='Условные реализации для тестирования оценки. Не OSPF, не опубликованный алгоритм. Время реакции и служебный обмен заданы в контрольном генераторе; нельзя переносить результат на реальные протоколы.')
    m['environment'].update(execution_source='deterministic_packet_fixture_generator',queue_discipline='FIFO_per_directed_link',
        buffer_limit_bytes=spec['buffer'],initial_state_ru='Все пути установлены; пользовательские очереди пусты; каналы доступны.',
        note_ru='Упрощённый генератор контрольных наблюдений, не ПАК и не орбитальная имитационная модель. Пакет следует пути, выбранному при отправке; обработка на каждом переходе 0,1 мс. Буфер учитывает обслуживаемые и ожидающие пакеты. Передача, пересекающая отключение, отменяется без включения незавершённых байтов в счётчики.')
    m['network']=dict(network_id=f'NET_TWO_PATHS_{n}',directed=True,nodes=nodes,
        links=[{k:v for k,v in e.items() if not k.startswith('_')} for e in links.values()],
        orbital_description={'type':'abstract_topology','plane_ids':['PL01'],'orbital_elements':None})
    flows=[]
    for fid in ['F01','F02']:
        source,destination=('G01','G02') if fid=='F01' else ('G02','G01')
        flows.append(dict(flow_id=fid,source_node=source,destination_node=destination,transport='UDP',
            packetization=dict(payload_bytes=1000,network_header_bytes=28,fragmentation=False,
                transport_retransmission=False,duplication=False),
            generation=dict(type='periodic',start_s=first/NS,interval_s=interval/NS,packet_count=count,stop_s=12.0,
                nominal_payload_rate_bps=spec['pps']*8000,first_packet_index=1)))
    m['traffic']['flows']=flows;m['scenario']['events']=events
    meas=m['measurement'];meas.update(capture_start_s=0.0,capture_end_s=14.0,evaluation_start_s=0.0,evaluation_end_s=12.0,
        channel_nominal_interval_s=.5,goodput_notes_ru='Первое корректное получение внутри [0;12); более поздний приём участвует в задержке/потерях, если соблюдён тайм-аут.')
    meas['balance']['selected_link_ids']=list(links)
    meas['stability']['checks']=[dict(check_id=f'{fid}_ST{k+1:02d}',flow_id=fid,time_start_s=t,horizon_s=1.0)
        for fid in paths for k,t in enumerate([1.0,3.5,6.0,9.0])]
    meas['adaptivity']['checks']=[dict(check_id=f'{fid}_AD01',flow_id=fid,event_id='E01')
        for fid in paths if any(l in failed for l in paths[fid]['primary'])]
    meas['adaptivity'].update(horizon_s=2.0,confirmation_window_s=.2,
        note_ru='Показатель главы 3: фактическое среднее времени завершённых задач; незавершённое время >2 с, без подстановки 2 с как результата. Восстановление E02 не является отдельной проверкой отказа.')
    m['extensions']={'test_suite':{'fixture_id':exp,'purpose_ru':spec['title'],'comparison_group':spec['group'],
        'not_real_pak_data':True,'traffic_model':'deterministic_periodic','satellite_count':n,
        'generation_parameters':spec,'generator_version':'1.0',
        'limits_ru':'Не моделируются орбиты, радиофизика, протокол обнаружения отказов, обучение, транспортные повторы. Это отладочный набор для формул и импорта.'}}
    dest.mkdir(parents=True,exist_ok=True)
    tables={'packets.csv':packet_rows,'routes.csv':route_rows,'channels.csv':channel_rows}
    for name,rows in tables.items():
        with (dest/name).open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=m['file_contract']['table_headers'][name],lineterminator='\r\n');w.writeheader();w.writerows(rows)
    m['export_status']['tables']={name:dict(row_count=len(rows),size_bytes=(dest/name).stat().st_size,sha256=sha(dest/name)) for name,rows in tables.items()}
    dump_json(dest/'experiment.json',m)
    ledger_dir.mkdir(parents=True,exist_ok=True)
    trace.sort(key=lambda x:(x['time_ns'],x['kind'],x.get('packet_id',''),x.get('link_id',''),x.get('flow_id','')))
    with (ledger_dir/(exp+'.jsonl')).open('w',encoding='utf-8',newline='\n') as f:
        for x in trace:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    return dict(experiment_id=exp,satellites=n,packets=len(packet_rows),routes=len(route_rows),channels=len(channel_rows),
        drop_reasons=dict(__import__('collections').Counter(p['drop'] for p in packets.values() if p['rx'] is None)))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=HERE.parent/'experiments');ap.add_argument('--ledger-out',type=Path,default=HERE.parent/'results/oracle_traces');args=ap.parse_args()
    for spec in SPECS:print(json.dumps(generate_one(spec,args.out/spec['id'],args.ledger_out),ensure_ascii=False))
if __name__=='__main__':main()

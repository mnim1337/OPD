"""Независимый численный контроль из событий генератора, не из семи готовых чисел.
Fraction вместо Decimal; не импортирует assess_chapter3 или его функции.
Это независимый путь расчёта на общих синтетических наблюдениях, не независимая
экспериментальная база и не эмпирическая валидация модели реальной сети.
"""
from __future__ import annotations
import argparse, csv, json
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
NS=10**9
KEYS=['P_zad','P_pr','P_pot','P_bal','P_ust','P_ad','P_res']
def fq(x):return F(str(x))
def evaluate(folder,tracefile,profile):
    m=json.loads((folder/'experiment.json').read_text(encoding='utf-8'))
    trace=[json.loads(x) for x in tracefile.read_text(encoding='utf-8').splitlines()]
    es=fq(m['measurement']['evaluation_start_s']);ee=fq(m['measurement']['evaluation_end_s']);T=ee-es
    timeout=fq(m['measurement']['loss_timeout_s']);h=fq(m['measurement']['adaptivity']['horizon_s']);conf=fq(m['measurement']['adaptivity']['confirmation_window_s'])
    tx={x['packet_id']:x for x in trace if x['kind']=='app_tx'};rx={x['packet_id']:x for x in trace if x['kind']=='app_rx'}
    cohort=[p for p in tx.values() if es<=F(p['time_ns'],NS)<ee]
    good=[p for p in cohort if p['packet_id'] in rx and F(rx[p['packet_id']]['time_ns']-p['time_ns'],NS)<=timeout]
    arrivals=[x for x in rx.values() if es<=F(x['time_ns'],NS)<ee]
    expected={
        'P_zad':sum((F(rx[p['packet_id']]['time_ns']-p['time_ns'],NS) for p in good),F(0))/len(good) if good else None,
        'P_pr':F(8*sum(p['payload_bytes'] for p in arrivals))/T,
        'P_pot':F(len(cohort)-len(good),len(cohort))}
    links={e['link_id']:e for e in m['network']['links']}
    events=[e for e in m['scenario']['events'] if e['result']=='executed']
    def up(lid,t):
        result=links[lid]['initial_up']
        for ev in events:
            if lid in ev['object_ids'] and fq(ev['actual_time_s'])<=t:result=ev['changes'].get('link_up',result)
        return result
    def survives(path,start,stop):
        if not path:return False
        for lid in path:
            if not up(lid,start):return False
            for ev in events:
                if lid in ev['object_ids'] and start<fq(ev['actual_time_s'])<stop and ev['changes'].get('link_up') is False:return False
        return True
    installed=defaultdict(list)
    for tr in trace:
        if tr['kind']=='route_install':installed[tr['flow_id']].append((F(tr['time_ns'],NS),tr['path']))
    for x in installed.values():x.sort()
    def path_at(fid,t):return [p for tt,p in installed[fid] if tt<=t][-1]
    sb=[]
    for chk in m['measurement']['stability']['checks']:
        a=fq(chk['time_start_s']);sb.append(survives(path_at(chk['flow_id'],a),a,a+fq(chk['horizon_s'])))
    expected['P_ust']=F(sum(sb),len(sb))
    taus=[]
    for chk in m['measurement']['adaptivity']['checks']:
        ev=next(x for x in events if x['event_id']==chk['event_id']);a=fq(ev['actual_time_s']);fid=chk['flow_id']
        # Candidate starts are trajectory or topology changes, not regular sampling timestamps.
        candidates=sorted({a}|{tt for tt,p in installed[fid] if a<=tt<=a+h}|{fq(e['actual_time_s']) for e in events if a<=fq(e['actual_time_s'])<=a+h})
        found=None
        for t in candidates:
            p=path_at(fid,t)
            if p and survives(p,t,t+conf) and all(p==p2 for tt,p2 in installed[fid] if t<tt<t+conf):found=t-a;break
        taus.append(found)
    expected['P_ad']=sum(taus,F(0))/len(taus) if all(x is not None for x in taus) else None
    step=fq(m['measurement']['channel_nominal_interval_s']);grid=[es];t=es
    while t<ee:t=min(ee,t+step);grid.append(t)
    selected=m['measurement']['balance']['selected_link_ids'];js=[];table_counts=defaultdict(lambda:defaultdict(int))
    for a,b in zip(grid,grid[1:]):
        traffic=defaultdict(int)
        for x in trace:
            if x['kind']=='link_tx_complete' and a<=F(x['time_ns'],NS)<b and x['category']=='data':traffic[x['link_id']]+=x['bytes']
        rhos=[F(8*traffic[lid])/ (fq(links[lid]['initial_capacity_bps'])*(b-a)) for lid in selected if up(lid,a)]
        if not any(rhos):raise ValueError('oracle: zero data interval')
        j=sum(rhos,F(0))**2/(len(rhos)*sum((x*x for x in rhos),F(0)));js.append((b-a)*j/T)
    expected['P_bal']=sum(js,F(0))
    expected['P_res']=F(sum(x['bytes'] for x in trace if x['kind']=='link_tx_complete' and x['category']=='routing' and es<=F(x['time_ns'],NS)<ee))
    # Check ALL channel rows against atomic transmission ledger, not only aggregate metrics.
    serial=[x for x in trace if x['kind']=='link_tx_complete']
    with (folder/'channels.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
    cerrors=[]
    for row in rows:
        a,b=fq(row['time_start_s']),fq(row['time_end_s']);lid=row['link_id']
        for cat,col in [('data','tx_data_bytes'),('routing','tx_routing_bytes')]:
            v=sum(x['bytes'] for x in serial if x['link_id']==lid and x['category']==cat and a<=F(x['time_ns'],NS)<b)
            if v!=int(row[col]):cerrors.append((lid,str(a),col,v,row[col]))
    # FIFO physical serialization bounds and accounting consistency.
    spans=defaultdict(list)
    for x in serial:spans[x['link_id']].append(x)
    overlap=[];capacity_errors=[]
    for lid,xs in spans.items():
        xs.sort(key=lambda x:(x['start_ns'],x['time_ns']))
        for left,right in zip(xs,xs[1:]):
            if left['time_ns']>right['start_ns']:overlap.append(lid)
        for x in xs:
            cap=links[lid]['initial_capacity_bps']
            if cap*(x['time_ns']-x['start_ns'])<8*x['bytes']*NS:capacity_errors.append(lid)
    def fvalue(x,config):
        pp=[(fq(a),fq(b)) for a,b in config['points']]
        if x is None:return pp[-1][1]
        if x<=pp[0][0]:return pp[0][1]
        if x>=pp[-1][0]:return pp[-1][1]
        idx=next(i for i in range(len(pp)-1) if pp[i][0]<=x<=pp[i+1][0]);a,b=pp[idx];c,d=pp[idx+1]
        return b+(d-b)*(x-a)/(c-a)
    norm={}
    for key,x in expected.items():
        if x is None and key=='P_ad':
            lo=fvalue(h,profile['metrics'][key]);hi=fvalue(None,profile['metrics'][key]);assert lo==hi
            norm[key]=lo
        else:norm[key]=fvalue(x,profile['metrics'][key])
    integral=100*sum((fq(profile['metrics'][k]['weight'])*norm[k] for k in KEYS),F(0))
    return {'source':'independent_fraction_reconstruction_from_atomic_generator_trace',
        'expected_metrics':{k:dict(value=None if v is None else float(v),fraction=None if v is None else str(v)) for k,v in expected.items()},
        'P_ad_lower_bound_s':float(h) if expected['P_ad'] is None else None,
        'expected_normalized':{k:float(v) for k,v in norm.items()},'expected_integral_score':float(integral),
        'expected_integral_fraction':str(integral),'sent_packets':len(cohort),'timely_received':len(good),
        'channel_counter_errors':cerrors,'serialization_overlap_errors':overlap,'serialization_capacity_errors':capacity_errors,
        'ledger_channel_checks':len(rows)*2,'ledger_transmission_count':len(serial)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('folder',type=Path);ap.add_argument('trace',type=Path);ap.add_argument('profile',type=Path);ap.add_argument('--out',type=Path);a=ap.parse_args()
    d=evaluate(a.folder,a.trace,json.loads(a.profile.read_text(encoding='utf-8')));s=json.dumps(d,ensure_ascii=False,indent=2)+'\n'
    if a.out:a.out.write_text(s,encoding='utf-8')
    else:print(s)
if __name__=='__main__':main()

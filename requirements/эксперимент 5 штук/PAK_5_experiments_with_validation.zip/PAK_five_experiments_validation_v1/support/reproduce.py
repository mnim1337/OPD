"""Воспроизведение пяти опытов, расчёта главы 3 и численного контроля.
Запуск из корня комплекта: python support/reproduce.py --out recomputed
Все расчётные зависимости — стандартная библиотека Python.
"""
from __future__ import annotations
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
import generate_experiments as gen
import assess_chapter3 as assess
import independent_oracle as oracle
ROOT=Path(__file__).resolve().parent.parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=ROOT/'recomputed');a=ap.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
    p=json.loads((ROOT/'support/profile_demo.json').read_text(encoding='utf-8'));checks=[]
    for spec in gen.SPECS:
        name=spec['id'];d=out/'experiments'/name
        gen.generate_one(spec,d,out/'oracle_traces')
        for f in sorted((ROOT/'experiments'/name).iterdir()):
            if f.read_bytes()!=(d/f.name).read_bytes():raise SystemExit(f'FAIL: отличаются байты {name}/{f.name}')
        actual=assess.assess(d,p);ref=oracle.evaluate(d,out/'oracle_traces'/f'{name}.jsonl',p)
        for key,expected in ref['expected_metrics'].items():
            val=actual['metrics'][key]['value']
            if expected['value'] is None:
                if val is not None:raise SystemExit(f'FAIL: цензурирование {name}/{key}')
            elif abs(val-expected['value'])>1e-10:raise SystemExit(f'FAIL: {name}/{key}')
        if abs(actual['integral_score']['value']-ref['expected_integral_score'])>1e-9:raise SystemExit('FAIL: интегральная оценка')
        if ref['channel_counter_errors'] or ref['serialization_overlap_errors'] or ref['serialization_capacity_errors']:raise SystemExit('FAIL: атомарный журнал')
        gen.dump_json(out/f'{name}_assessment.json',actual);gen.dump_json(out/f'{name}_oracle.json',ref)
        checks.append({'experiment':name,'status':'PASS','I':actual['integral_score']['value']})
    for script,args in [('test_reference_validator.py',[str(ROOT/'support/reference_template')]),('test_model.py',[])]:
        proc=subprocess.run([sys.executable,str(ROOT/'support'/script),*args],capture_output=True,text=True,encoding='utf-8')
        (out/(script+'.log')).write_text(proc.stdout+proc.stderr,encoding='utf-8')
        if proc.returncode:raise SystemExit(proc.stdout+proc.stderr)
    gen.dump_json(out/'reproduction_summary.json',{'status':'PASS','experiments':checks,'reference_validator_tests':32,'model_tests':46,'synthetic_only':True})
    print(json.dumps({'status':'PASS','experiments':checks,'out':str(out)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()

from __future__ import annotations
import copy,csv,hashlib,json,random,shutil,tempfile,unittest
from decimal import Decimal as D
from pathlib import Path
import assess_chapter3 as model
import generate_experiments as generator
import validate_export as schema
ROOT=Path(__file__).resolve().parent.parent
EXPS=sorted((ROOT/'experiments').iterdir())
PROFILE=json.loads((ROOT/'support/profile_demo.json').read_text(encoding='utf-8'))

def clone_ctx(i=0):return copy.deepcopy(schema.validate(EXPS[i])[2])
def refresh(folder,name):
    p=folder/name;m=json.loads((folder/'experiment.json').read_text());raw=p.read_bytes()
    with p.open(encoding='utf-8',newline='') as f:n=sum(1 for _ in csv.DictReader(f))
    m['export_status']['tables'][name]={'row_count':n,'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    (folder/'experiment.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.results=[model.assess(p,PROFILE) for p in EXPS]
        cls.oracles=[json.loads((ROOT/'results'/f'{p.name}_oracle.json').read_text()) for p in EXPS]
    def test_01_exactly_five_sets_four_files(self):
        self.assertEqual(len(EXPS),5)
        for p in EXPS:self.assertEqual({x.name for x in p.iterdir()},schema.EXPECTED_FILES)
    def test_02_original_schema_passes_without_warnings(self):
        for p in EXPS:self.assertEqual(schema.validate(p)[1],[])
    def test_03_all_sources_explicitly_synthetic(self):
        for p in EXPS:
            m=json.loads((p/'experiment.json').read_text());self.assertEqual(m['data_origin'],'synthetic_reference');self.assertTrue(m['extensions']['test_suite']['not_real_pak_data'])
    def test_04_satellite_counts(self):
        counts=[]
        for p in EXPS:
            m=json.loads((p/'experiment.json').read_text());counts.append(sum(n['node_type']=='satellite' for n in m['network']['nodes']))
        self.assertEqual(counts,[4,4,12,12,24])
    def test_05_first_pair_has_identical_external_conditions(self):
        a,b=[json.loads((p/'experiment.json').read_text()) for p in EXPS[:2]]
        for k in ['network','traffic','scenario','measurement','environment']:self.assertEqual(a[k],b[k],k)
        self.assertNotEqual(a['algorithm']['algorithm_id'],b['algorithm']['algorithm_id'])
    def test_06_load_pair_same_network_and_algorithm_settings(self):
        a,b=[json.loads((p/'experiment.json').read_text()) for p in EXPS[2:4]]
        self.assertEqual(a['network'],b['network']);self.assertEqual(a['algorithm']['settings'],b['algorithm']['settings'])
        self.assertEqual(b['traffic']['flows'][0]['generation']['nominal_payload_rate_bps'],4*a['traffic']['flows'][0]['generation']['nominal_payload_rate_bps'])
    def test_07_independent_oracle_all_exact_metrics(self):
        for r,o in zip(self.results,self.oracles):
            for k,e in o['expected_metrics'].items():
                if e['value'] is None:self.assertIsNone(r['metrics'][k]['value'])
                else:self.assertAlmostEqual(r['metrics'][k]['value'],e['value'],places=10)
    def test_08_independent_oracle_all_scores(self):
        for r,o in zip(self.results,self.oracles):self.assertAlmostEqual(r['integral_score']['value'],o['expected_integral_score'],places=10)
    def test_09_all_channel_counts_match_atomic_trace(self):
        for o in self.oracles:self.assertEqual(o['channel_counter_errors'],[])
    def test_10_no_simultaneous_serializations_on_single_link(self):
        for o in self.oracles:self.assertEqual(o['serialization_overlap_errors'],[])
    def test_11_serialization_obeys_capacities(self):
        for o in self.oracles:self.assertEqual(o['serialization_capacity_errors'],[])
    def test_12_hand_control_loss_first(self):
        r=self.results[0];self.assertEqual(r['diagnostics']['sent_packets'],480);self.assertEqual(r['diagnostics']['timely_received'],455)
        self.assertAlmostEqual(r['metrics']['P_pot']['value'],25/480)
    def test_13_hand_control_goodput_first(self):
        self.assertEqual(self.results[0]['metrics']['P_pr']['value'],453*1000*8/12)
    def test_14_late_receptions_not_false_losses(self):
        d=self.results[0]['diagnostics'];self.assertEqual(d['received_after_window'],2);self.assertEqual(d['timely_received'],d['received_in_window']+2)
    def test_15_control_reaction_times_not_confirmation_end(self):
        self.assertEqual(self.results[0]['metrics']['P_ad']['value'],.6);self.assertEqual(self.results[1]['metrics']['P_ad']['value'],.1)
    def test_16_faster_repair_does_not_force_lower_conditional_delay(self):
        a,b=self.results[:2];self.assertLess(b['metrics']['P_pot']['value'],a['metrics']['P_pot']['value'])
        self.assertGreater(b['metrics']['P_zad']['value'],a['metrics']['P_zad']['value'])
    def test_17_overload_generates_observed_queue_drops(self):
        self.assertEqual(self.results[2]['diagnostics']['drop_reasons'].get('queue_overflow',0),0)
        self.assertEqual(self.results[3]['diagnostics']['drop_reasons'].get('queue_overflow'),336)
        self.assertGreater(self.results[3]['metrics']['P_pot']['value'],self.results[2]['metrics']['P_pot']['value'])
    def test_18_censored_time_not_replaced_by_horizon(self):
        p=self.results[4]['metrics']['P_ad'];self.assertEqual(p['status'],'lower_bound');self.assertIsNone(p['value']);self.assertEqual(p['lower'],2);self.assertTrue(p['upper_unbounded']);self.assertTrue(p['lower_open'])
    def test_19_saturated_score_from_censored_input(self):
        self.assertEqual(self.results[4]['normalized_metrics']['P_ad']['value'],0);self.assertEqual(self.results[4]['integral_score']['status'],'exact')
    def test_20_non_saturated_censoring_produces_score_interval(self):
        ctx=clone_ctx(4);p,d=model.compute(ctx);pr=copy.deepcopy(PROFILE)
        pr['metrics']['P_ad']['points']=[[0,1],[.2,.9],[.6,.6],[4,0]]
        n,g,i=model.score(p,pr);self.assertEqual(i['status'],'bounded');self.assertGreater(i['upper'],i['lower'])
    def test_21_zero_traffic_interval_not_ignored(self):
        ctx=clone_ctx()
        for rs in ctx['by_link'].values():rs[0]['_tx_data_bytes']=0
        p,d=model.compute(ctx);self.assertEqual(p['P_bal']['status'],'undefined');self.assertEqual(model.score(p,PROFILE)[2]['status'],'undefined')
    def test_22_no_deliveries_delay_not_zero(self):
        ctx=clone_ctx()
        for r in ctx['packets']:r['_rx']=None;r['_copies']=0
        p,d=model.compute(ctx);self.assertEqual(p['P_pot']['value'],1);self.assertEqual(p['P_zad']['status'],'undefined');self.assertEqual(model.score(p,PROFILE)[2]['status'],'undefined')
    def test_23_no_adaptive_tasks_not_zero(self):
        ctx=clone_ctx();ctx['manifest']['measurement']['adaptivity']['checks']=[]
        p,d=model.compute(ctx);self.assertEqual(p['P_ad']['status'],'undefined')
    def test_24_static_path_survival_fixed_at_start(self):
        ctx=clone_ctx();fid='F01';rs=ctx['by_flow'][fid];old=rs[0];a=copy.deepcopy(old);b=copy.deepcopy(old)
        a['_b']=D('3.75');b['_a']=D('3.75');b['_path']=rs[2]['_path'];ctx['by_flow'][fid]=[a,b,*rs[1:]]
        ctx['manifest']['measurement']['stability']['checks']=[dict(check_id='FIXED',flow_id=fid,time_start_s=3.5,horizon_s=1)]
        p,d=model.compute(ctx);self.assertEqual(p['P_ust']['value'],0)
    def test_25_route_identifiers_do_not_define_path_identity(self):
        ctx=clone_ctx();rs=ctx['by_flow']['F01'];a=copy.deepcopy(rs[2]);b=copy.deepcopy(rs[2]);a['_b']=D('4.65');b['_a']=D('4.65');b['path_id']='DIFFERENT_SAME_PATH'
        ctx['by_flow']['F01']=[*rs[:2],a,b,*rs[3:]]
        p,d=model.compute(ctx);self.assertEqual(p['P_ad']['value'],D('.6'))
    def test_26_unaffected_event_not_measured_as_zero(self):
        ctx=clone_ctx();ctx['events']['E01']['actual_time_s']=2
        p,d=model.compute(ctx);self.assertEqual(p['P_ad']['status'],'undefined');self.assertTrue(d['adaptivity_ineligible'])
    def test_27_physical_partition_separate_from_algorithm_failure(self):
        ctx=clone_ctx();backup=ctx['by_flow']['F01'][2]['_path'];lid=backup[1]
        for r in ctx['by_link'][lid]:
            if D(4)<=r['_a']<D(7):r['_up']=False;r['_cap']=D(0);r['_tx_data_bytes']=0
        p,d=model.compute(ctx);self.assertEqual(p['P_ad']['status'],'undefined')
    def test_28_profiles_monotone_and_saturating(self):
        for key,direction in zip(model.KEYS,model.DIRECTIONS):
            mm=PROFILE['metrics'][key];lo,hi=mm['points'][0][0],mm['points'][-1][0]
            yy=[model.norm(D(str(lo))+(D(str(hi))-D(str(lo)))*k/50,mm) for k in range(51)]
            self.assertEqual(yy,sorted(yy,reverse=direction=='min'))
            self.assertEqual(model.norm(D(str(lo))-1,mm),yy[0]);self.assertEqual(model.norm(D(str(hi))+1,mm),yy[-1])
    def test_29_equal_anchors_rejected(self):
        p=copy.deepcopy(PROFILE);p['metrics']['P_zad']['points'][1][0]=p['metrics']['P_zad']['points'][0][0]
        with self.assertRaises(model.ModelError):model.validate_profile(p)
    def test_30_bad_weights_rejected(self):
        p=copy.deepcopy(PROFILE);p['metrics']['P_res']['weight']=.9
        with self.assertRaises(model.ModelError):model.validate_profile(p)
    def test_31_zero_weight_rejected_full_seven(self):
        p=copy.deepcopy(PROFILE);p['metrics']['P_res']['weight']=0;p['metrics']['P_ad']['weight']+=.08
        with self.assertRaises(model.ModelError):model.validate_profile(p)
    def test_32_seconds_to_milliseconds_invariance(self):
        metrics,_=model.compute(clone_ctx());pr=copy.deepcopy(PROFILE);mm=copy.deepcopy(metrics)
        for key in ['P_zad','P_ad']:
            for field in ['value','lower','upper']:
                if mm[key][field] is not None:mm[key][field]*=1000
            pr['metrics'][key]['points']=[[D(str(x))*1000,y] for x,y in pr['metrics'][key]['points']]
        self.assertEqual(model.score(metrics,PROFILE)[2]['value'],model.score(mm,pr)[2]['value'])
    def test_33_partial_packet_observation_not_false_loss(self):
        ctx=clone_ctx();p=ctx['packets'][0];p['observation_status']='partial'
        met,dd=model.compute(ctx);self.assertEqual(met['P_pot']['status'],'bounded');self.assertAlmostEqual(met['P_pot']['upper']-met['P_pot']['lower'],D(1)/480,places=40)
    def test_34_missing_routing_counter_not_zero(self):
        ctx=clone_ctx();row=next(iter(ctx['by_link'].values()))[0];row['_tx_routing_bytes']=None;row['observation_status']='partial'
        p,d=model.compute(ctx);self.assertEqual(p['P_res']['status'],'bounded');self.assertGreater(p['P_res']['upper'],p['P_res']['lower'])
    def test_35_global_log_loss_rejected(self):
        ctx=clone_ctx();ctx['manifest']['export_status']['data_logging_complete']=False
        with self.assertRaises(model.ModelError):model.compute(ctx)
    def test_36_uncertain_clock_not_treated_as_exact(self):
        ctx=clone_ctx();ctx['manifest']['measurement']['clock_error_bound_s']=.02
        with self.assertRaises(model.ModelError):model.compute(ctx)
    def test_37_canonical_scalar_calculation_reproducible(self):
        for p,r in zip(EXPS,self.results):self.assertEqual(model.assess(p,PROFILE),r)
    def test_38_rows_order_does_not_change_metrics(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)/'E';shutil.copytree(EXPS[0],folder)
            for name in schema.HEADERS:
                with (folder/name).open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
                with (folder/name).open('w',encoding='utf-8',newline='') as f:
                    w=csv.DictWriter(f,fieldnames=schema.HEADERS[name],lineterminator='\r\n');w.writeheader();w.writerows(reversed(rows))
                refresh(folder,name)
            r=model.assess(folder,PROFILE);self.assertEqual(r['metrics'],self.results[0]['metrics']);self.assertEqual(r['integral_score'],self.results[0]['integral_score'])
    def test_39_weight_sensitivity_bound(self):
        a,b=self.results[:2];u=[D(str(b['normalized_metrics'][k]['value']))-D(str(a['normalized_metrics'][k]['value'])) for k in model.KEYS]
        w=[D(str(PROFILE['metrics'][k]['weight'])) for k in model.KEYS];nom=100*sum(x*y for x,y in zip(w,u));rng=random.Random(47)
        for _ in range(200):
            i,j=rng.sample(range(7),2);v=w[:];shift=min(v[i]/2,D('0.025'));v[i]-=shift;v[j]+=shift
            changed=100*sum(x*y for x,y in zip(v,u));self.assertLessEqual(abs(changed-nom),100*sum(abs(x-y) for x,y in zip(v,w))+D('1e-12'))
        self.assertGreater(nom,5)
    def test_40_normalize_before_average_not_after(self):
        mm=PROFILE['metrics']['P_zad'];a,b=D('.02'),D('.6')
        self.assertNotEqual((model.norm(a,mm)+model.norm(b,mm))/2,model.norm((a+b)/2,mm))
    def test_41_existing_reference_latest_model(self):
        p=ROOT/'support/reference_template';r=model.assess(p,PROFILE)
        self.assertEqual(r['diagnostics']['timely_received'],38);self.assertEqual(r['metrics']['P_pr']['value'],28800);self.assertEqual(r['metrics']['P_ad']['value'],.5)
    def test_42_regeneration_is_byte_identical(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            for spec,src in zip(generator.SPECS,EXPS):
                dst=out/spec['id'];generator.generate_one(spec,dst,out/'traces')
                for f in src.iterdir():self.assertEqual(f.read_bytes(),(dst/f.name).read_bytes(),f'{spec["id"]}/{f.name}')
    def test_43_monotonic_score_single_metric(self):
        met,_=model.compute(clone_ctx());nom=model.score(met,PROFILE)[2]['value']
        for k,d in zip(model.KEYS,model.DIRECTIONS):
            p=copy.deepcopy(met);value=p[k]['value'];new=value*D('.9') if d=='min' else value*D('1.05');p[k]=model.exact(new)
            self.assertGreaterEqual(model.score(p,PROFILE)[2]['value'],nom)
    def test_44_weights_not_renormalized_for_unknown(self):
        met,_=model.compute(clone_ctx());p=copy.deepcopy(met);p['P_res']=model.bounded(0,250000)
        i=model.score(p,PROFILE)[2];self.assertEqual(i['upper']-i['lower'],D(8))
    def test_45_route_stability_known_hand_counts(self):
        for r in self.results[:4]:self.assertEqual(r['metrics']['P_ust']['value'],6/8)
        self.assertEqual(self.results[4]['metrics']['P_ust']['value'],5/8)
    def test_46_adding_candidates_does_not_change_score(self):
        before=self.results[0]['integral_score']
        for p in EXPS[1:]:model.assess(p,PROFILE)
        self.assertEqual(model.assess(EXPS[0],PROFILE)['integral_score'],before)

if __name__=='__main__':unittest.main(verbosity=2)
